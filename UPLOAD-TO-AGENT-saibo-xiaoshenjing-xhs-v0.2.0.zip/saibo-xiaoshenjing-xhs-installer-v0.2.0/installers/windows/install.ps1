[CmdletBinding()]
param(
    [ValidateSet("codex", "workbuddy-user", "workbuddy-project")]
    [string]$Mode = "codex",
    [string]$TargetRoot,
    [switch]$Yes
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PackageRoot = (Resolve-Path (Join-Path $ScriptDir "..\..")).Path
$PayloadDir = Join-Path $PackageRoot "payload\saibo-xiaoshenjing-xhs"
$SkillName = "saibo-xiaoshenjing-xhs"
$BackupRoot = Join-Path $env:USERPROFILE ".saibo-xhs-installer\backups"

if (-not (Test-Path (Join-Path $PayloadDir "SKILL.md") -PathType Leaf)) {
    throw "安装包不完整：找不到 payload\saibo-xiaoshenjing-xhs\SKILL.md"
}

if ([string]::IsNullOrWhiteSpace($TargetRoot)) {
    if ($Mode -eq "codex") {
        $TargetRoot = Join-Path $env:USERPROFILE ".agents\skills"
    }
    elseif ($Mode -eq "workbuddy-user") {
        $TargetRoot = Join-Path $env:USERPROFILE ".codebuddy\skills"
    }
    else {
        $ProjectRoot = Read-Host "请输入 WorkBuddy 项目绝对路径"
        if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
            throw "未提供 WorkBuddy 项目路径。"
        }
        $TargetRoot = Join-Path ([System.IO.Path]::GetFullPath($ProjectRoot)) ".codebuddy\skills"
    }
}
else {
    $TargetRoot = [System.IO.Path]::GetFullPath($TargetRoot)
}

$TargetDir = Join-Path $TargetRoot $SkillName
Write-Host "将安装 1 个 Skill：$SkillName"
Write-Host "源目录：$PayloadDir"
Write-Host "目标目录：$TargetDir"
Write-Host "若目标已存在，会先备份到：$BackupRoot"
Write-Host "不会安装依赖、修改系统设置或发布内容。"

if (-not $Yes) {
    $Answer = Read-Host "继续安装？输入 yes"
    if ($Answer -ne "yes") {
        Write-Host "已取消，未修改任何文件。"
        exit 0
    }
}

New-Item -ItemType Directory -Force -Path $TargetRoot | Out-Null
New-Item -ItemType Directory -Force -Path $BackupRoot | Out-Null
if (Test-Path $TargetDir) {
    $Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $BackupDir = Join-Path $BackupRoot "$SkillName-$Timestamp"
    Move-Item -Path $TargetDir -Destination $BackupDir
    Write-Host "已备份旧版本：$BackupDir"
}

Copy-Item -Path $PayloadDir -Destination $TargetDir -Recurse

$Required = @(
    "SKILL.md",
    "references\style-system.md",
    "references\title-formulas.md",
    "scripts\check_environment.py",
    "scripts\render_inner_cards.py"
)
foreach ($RelativePath in $Required) {
    if (-not (Test-Path (Join-Path $TargetDir $RelativePath) -PathType Leaf)) {
        throw "安装校验失败，缺少：$RelativePath"
    }
}

Write-Host "安装完成：$TargetDir"
$Py = Get-Command py -ErrorAction SilentlyContinue
if ($null -ne $Py) {
    Write-Host "下面执行只读环境检查；非零结果只表示出图环境未就绪。"
    & py -3 (Join-Path $TargetDir "scripts\check_environment.py")
    if ($LASTEXITCODE -ne 0) {
        Write-Host "标题和文案阶段仍可用；请按检查结果补齐出图环境。"
    }
}
else {
    Write-Host "未发现 py；标题和文案阶段仍可使用，出图阶段暂不可用。"
}
Write-Host "下一步：刷新 Agent，然后用 examples\first-use-material.md 只跑标题阶段。"

#!/bin/zsh
set -eu

SCRIPT_DIR="${0:A:h}"
PACKAGE_ROOT="${SCRIPT_DIR:h:h}"
PAYLOAD_DIR="$PACKAGE_ROOT/payload/saibo-xiaoshenjing-xhs"
SKILL_NAME="saibo-xiaoshenjing-xhs"
BACKUP_ROOT="$HOME/.saibo-xhs-installer/backups"
MODE="codex"
CUSTOM_ROOT=""
ASSUME_YES="no"

usage() {
  print "用法: 安装.command [--mode codex|workbuddy-user|workbuddy-project] [--target-root 目录] [--yes]"
}

while (( $# > 0 )); do
  case "$1" in
    --mode) MODE="$2"; shift 2 ;;
    --target-root) CUSTOM_ROOT="$2"; shift 2 ;;
    --yes) ASSUME_YES="yes"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) print -u2 "未知参数: $1"; usage; exit 2 ;;
  esac
done

if [[ ! -f "$PAYLOAD_DIR/SKILL.md" ]]; then
  print -u2 "安装包不完整：找不到 $PAYLOAD_DIR/SKILL.md"
  exit 3
fi

if [[ -n "$CUSTOM_ROOT" ]]; then
  TARGET_ROOT="${CUSTOM_ROOT:A}"
elif [[ "$MODE" == "codex" ]]; then
  TARGET_ROOT="$HOME/.agents/skills"
elif [[ "$MODE" == "workbuddy-user" ]]; then
  TARGET_ROOT="$HOME/.codebuddy/skills"
elif [[ "$MODE" == "workbuddy-project" ]]; then
  print "请输入 WorkBuddy 项目绝对路径："
  read -r PROJECT_ROOT
  if [[ -z "$PROJECT_ROOT" ]]; then
    print -u2 "未提供项目路径。"
    exit 4
  fi
  TARGET_ROOT="${PROJECT_ROOT:A}/.codebuddy/skills"
else
  print -u2 "不支持的模式: $MODE"
  exit 2
fi

TARGET_DIR="$TARGET_ROOT/$SKILL_NAME"
print "将安装 1 个 Skill：$SKILL_NAME"
print "源目录：$PAYLOAD_DIR"
print "目标目录：$TARGET_DIR"
print "若目标已存在，会先备份到：$BACKUP_ROOT"
print "不会安装依赖、修改系统设置或发布内容。"

if [[ "$ASSUME_YES" != "yes" ]]; then
  print "继续安装？输入 yes："
  read -r ANSWER
  if [[ "$ANSWER" != "yes" ]]; then
    print "已取消，未修改任何文件。"
    exit 0
  fi
fi

mkdir -p "$TARGET_ROOT" "$BACKUP_ROOT"
if [[ -e "$TARGET_DIR" ]]; then
  TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
  BACKUP_DIR="$BACKUP_ROOT/${SKILL_NAME}-$TIMESTAMP"
  mv "$TARGET_DIR" "$BACKUP_DIR"
  print "已备份旧版本：$BACKUP_DIR"
fi

cp -R "$PAYLOAD_DIR" "$TARGET_DIR"

for REQUIRED in \
  "SKILL.md" \
  "references/style-system.md" \
  "references/title-formulas.md" \
  "scripts/check_environment.py" \
  "scripts/render_inner_cards.py"
do
  if [[ ! -f "$TARGET_DIR/$REQUIRED" ]]; then
    print -u2 "安装校验失败，缺少：$REQUIRED"
    exit 5
  fi
done

print "安装完成：$TARGET_DIR"
if command -v python3 >/dev/null 2>&1; then
  print "下面执行只读环境检查；非零结果只表示出图环境未就绪。"
  python3 "$TARGET_DIR/scripts/check_environment.py" || true
else
  print "未发现 python3；标题和文案阶段仍可使用，出图阶段暂不可用。"
fi
print "下一步：刷新 Agent，然后用 examples/first-use-material.md 只跑标题阶段。"

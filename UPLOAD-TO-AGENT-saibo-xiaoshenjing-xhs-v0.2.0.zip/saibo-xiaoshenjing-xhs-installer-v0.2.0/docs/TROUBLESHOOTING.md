# 常见故障与人工兜底

## Agent 没识别 Skill

- 检查目标目录是否多套了一层文件夹；
- 确认 `SKILL.md` 位于 Skill 根目录；
- Codex 重启或刷新；WorkBuddy 检查 Skill 是否启用；
- 仍失败时，直接让 Agent 读取安装目录中的 `SKILL.md`，完成首次标题体验，并记录框架版本和错误。

## Python 命令不存在

标题和正文阶段不受影响。出图阶段：

- macOS 尝试 `python3 --version`
- Windows 尝试 `py -3 --version`

没有 Python 时，先停在文字成果；只有用户同意后再安装 Python。

## Pillow 缺失

环境检查会给出建议命令。Agent 解释该依赖只用于确定性渲染，取得同意后才能安装。

## 中文字体缺失

设置 `SAIBO_XHS_FONT_SANS` 和 `SAIBO_XHS_FONT_SERIF` 指向已安装的中文字体文件；本包不分发系统字体。

## Agent 没有 imagegen

正常封面无法完成。人工兜底有两种：

1. 带着已确认文字换到支持 imagegen 的 Agent；
2. 用户明确同意后运行 `render_cover_fallback.py --confirmed-fallback` 生成简版封面。

交付时必须写清简版封面的生成方式。

## 标题阶段直接写了全文或出图

立即停止，把多余内容标记为未确认草稿；重新只输出 10 个候选、Top 3 和首选。不要把越过门槛的输出归档为正式发布包。

## 同名 Skill 已存在

不要覆盖或删除。安装器会创建时间戳备份；人工安装也应先备份。若新版失败，把备份目录移回原目标。

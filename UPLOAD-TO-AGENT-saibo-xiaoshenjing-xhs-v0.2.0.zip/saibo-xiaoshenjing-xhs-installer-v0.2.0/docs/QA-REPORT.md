# 本地 QA 记录

日期：2026-07-29  
版本：0.2.0  
执行机：macOS Darwin 25.3.0，Python 3.9.6，Pillow 10.4.0

## 已执行并通过

- manifest 声明为单 Skill，名称为 `saibo-xiaoshenjing-xhs`；
- 原始 Skill 快照的 5 个文件逐一校验 SHA-256；
- portable payload 必需文件齐全；
- 标题确认门、正文/逐页文字确认门、不自动发布边界仍存在；
- portable payload 不再依赖 `/Library/content_production`；
- 3 个 Python 脚本通过 `py_compile`；
- 内页渲染器使用测试 JSON 实际生成 2 张 1080×1440 PNG；
- macOS 安装器在临时目录完成安装；
- 安装后的 `SKILL.md` 与 payload 哈希一致；
- 环境检查识别 Python、Pillow、黑体和宋体，确定性渲染为 READY；
- Windows PowerShell 脚本括号平衡；
- Windows 安装器包含“先备份再复制”，不含删除操作；
- Windows CMD 入口正确调用 PowerShell 安装器。
- ZIP 根目录包含 `AGENTS.md` 与 `agent-install.json`；
- “上传 ZIP + 要求安装”被定义为默认、可回滚安装授权；
- Codex 与 WorkBuddy 在 macOS/Windows 上均有明确用户级默认目录；
- Agent 主路径不要求用户点击安装器，平台脚本仅作为 Agent 执行器与人工兜底。

执行命令：

```bash
cd /Users/naozhisair/CU_product/products/saibo-xiaoshenjing-xhs-installer
python3 tests/verify_package.py
```

结果：`ALL PACKAGE CHECKS PASSED`

## 尚未验证

- Windows 10/11 实机运行 `install.cmd`；
- WorkBuddy 当前桌面版本的真实 UI 上传与启用；
- Codex/WorkBuddy 中由真实参与者完成第一次标题结果；
- Agent 的 imagegen 正常封面链路；
- 用户付费、复用、留存或完整会员产品成立。

## 周四最小现场验证

先用一台 Windows 设备完成 `install.cmd → Agent 识别 → 示例标题阶段`，记录首个结果耗时和人工帮助；然后在 WorkBuddy UI 上传专用 ZIP。若失败，保留原始错误和版本号，不临场扩大产品范围。

# Agent 安装与使用协议

## 0. 接收安装意图

用户上传本 ZIP 并要求安装时，该请求已经授权默认、可回滚的安装。直接开始，不让用户点击脚本，也不重复询问“是否安装”。

安装完成后告诉用户：本包只安装了 `saibo-xiaoshenjing-xhs`；不会安装其他 Skill，不会发布或登录账号。

## 1. 检测环境

读取操作系统和当前 Agent：

- Codex：默认用户目录为 `.agents/skills/`。
- WorkBuddy：对话内自动安装默认使用用户目录 `.codebuddy/skills/`；Skills 页面直接导入时使用 WorkBuddy 专用 ZIP；用户指定项目时才使用项目 `.codebuddy/skills/`。
- 其他 Agent：只有在确认支持 `SKILL.md` 和相对资源后再继续。

## 2. 确定默认目标

Agent 内部确认以下信息后直接执行：

- 源：`payload/saibo-xiaoshenjing-xhs`
- 目标：解析后的绝对目录
- 同名 Skill：若存在，将移动到带时间戳的 `backups/`，不删除
- 依赖：文字阶段无依赖；出图阶段才需要 Python 3、Pillow 和中文字体
- 权限：只写 Skill 目标和备份目录

只有无法判断框架、没有已知 Skill 目录、需要提权、需要下载依赖，或用户要求非默认范围时才暂停询问。

## 3. 安装

### Codex

- macOS：`$HOME/.agents/skills/saibo-xiaoshenjing-xhs`
- Windows：`%USERPROFILE%\.agents\skills\saibo-xiaoshenjing-xhs`

由 Agent 调用自带执行器的非交互模式，或执行等价的可回滚复制操作。不得要求用户手动点击执行器。

### WorkBuddy

用户已经在 WorkBuddy Skills 页面时，直接上传：

`dist/saibo-xiaoshenjing-xhs-workbuddy-v0.2.0.zip`

用户把完整包上传到 WorkBuddy 对话时，Agent 默认安装到：

- macOS：`$HOME/.codebuddy/skills/saibo-xiaoshenjing-xhs`
- Windows：`%USERPROFILE%\.codebuddy\skills\saibo-xiaoshenjing-xhs`

若用户使用项目级 Skills，将 `payload/saibo-xiaoshenjing-xhs` 复制到：

`<project>/.codebuddy/skills/saibo-xiaoshenjing-xhs`

不要猜测项目路径；项目级安装只在用户明确指定项目时使用。

## 4. 安装后检查

确认目标目录至少包含：

- `SKILL.md`
- `references/style-system.md`
- `references/title-formulas.md`
- `references/portable-runtime.md`
- `assets/cover-layout-reference.png`
- `scripts/check_environment.py`
- `scripts/render_inner_cards.py`

再执行只读环境检查：

- macOS：`python3 scripts/check_environment.py`
- Windows：`py -3 scripts/check_environment.py`

环境检查失败不等于 Skill 完全不可用：标题与文案仍可运行；必须把“文字可用”和“出图可用”分别报告。

Codex 未出现 Skill 时，告诉用户需要重启或刷新当前 Agent；WorkBuddy 则检查 Skill 是否启用。

## 5. 第一次体验

读取 `examples/first-use-material.md`，调用已安装的 `$saibo-xiaoshenjing-xhs`：

> 请用这段示例素材，只执行标题阶段。给出素材主线、10 个候选、Top 3 和明确首选，然后停下来等我确认。

验收：

- 不超过 20 字；
- 每个候选有类型、SX 编号和理由；
- 至少覆盖 3 种心理触发器；
- 有 Top 3 和明确第 1 名；
- 没有正文、图片、正式发布包或发布动作。

## 6. 引导真实使用

第一次真实输入建议只给一段素材，并说明哪些是事实、哪些是个人判断、哪些不能公开。Agent 按两道门槛逐步推进，不一次性做完。

## 7. 引导迭代

读取 `docs/ITERATION-GUIDE.md`。先跑完一轮，再依据真实卡点复制出新版本；不得在没有反馈时大改核心流程。

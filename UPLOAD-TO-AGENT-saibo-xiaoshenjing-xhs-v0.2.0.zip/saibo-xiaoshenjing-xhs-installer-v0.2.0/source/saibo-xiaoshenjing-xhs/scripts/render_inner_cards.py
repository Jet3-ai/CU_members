#!/usr/bin/env python3
"""Render 赛博小神经 graphite-note inner carousel cards from JSON."""

import argparse
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


W, H = 1080, 1440
PAPER = (244, 241, 234)
GRAPHITE = "#55524D"
SECONDARY = "#6F6C66"
GHOST = "#E6E2DA"
SONGTI = "/System/Library/Fonts/Supplemental/Songti.ttc"
HIRAGINO = "/System/Library/Fonts/Hiragino Sans GB.ttc"

STYLES = {
    "small": {"size": 44, "color": SECONDARY, "line_gap": 17, "after": 62, "weight": 0},
    "body": {"size": 60, "color": GRAPHITE, "line_gap": 22, "after": 66, "weight": 0},
    "main": {"size": 86, "color": GRAPHITE, "line_gap": 30, "after": 78, "weight": 2},
    "emphasis": {"size": 54, "color": GRAPHITE, "line_gap": 21, "after": 68, "weight": 0},
}


def load_font(size, weight=0):
    try:
        return ImageFont.truetype(HIRAGINO, size=size, index=weight)
    except OSError as exc:
        raise RuntimeError(f"Hiragino Sans GB unavailable: {HIRAGINO}") from exc


def paper_image():
    base = Image.new("RGB", (W, H), PAPER)
    noise = Image.effect_noise((W, H), 6).convert("L")
    texture = Image.merge("RGB", (noise, noise, noise))
    return Image.blend(base, texture, 0.025)


def wrap_paragraph(draw, text, font, max_width):
    if not text:
        return [""]
    lines, current = [], ""
    for char in text:
        candidate = current + char
        width = draw.textbbox((0, 0), candidate, font=font)[2]
        if width <= max_width or not current:
            current = candidate
        else:
            lines.append(current)
            current = char
    if current:
        lines.append(current)
    return lines


def block_layout(draw, block, max_width=900):
    style_name = block.get("style", "body")
    if style_name not in STYLES:
        raise ValueError(f"Unknown style: {style_name}")
    spec = STYLES[style_name]
    font = load_font(spec["size"], spec["weight"])
    lines = []
    for paragraph in str(block.get("text", "")).split("\n"):
        lines.extend(wrap_paragraph(draw, paragraph, font, max_width))
    line_height = draw.textbbox((0, 0), "国", font=font)[3]
    height = len(lines) * line_height + max(0, len(lines) - 1) * spec["line_gap"]
    return spec, font, lines, line_height, height


def render_page(page, index, total, signature, output_dir):
    image = paper_image()
    draw = ImageDraw.Draw(image)
    blocks = page.get("blocks", [])
    if not blocks:
        raise ValueError(f"Page {index} has no blocks")

    layouts = [block_layout(draw, block) for block in blocks]
    total_height = sum(layout[4] + layout[0]["after"] for layout in layouts) - layouts[-1][0]["after"]
    if total_height > 850:
        raise ValueError(
            f"Page {index} is too dense ({total_height}px). Split the content into another page instead of shrinking it."
        )

    page_no = index - 1
    section = str(page.get("section", f"{page_no:02d}"))
    header_font = load_font(28, 2)
    ghost_font = load_font(176, 0)
    draw.text((82, 150), section, fill=GRAPHITE, font=header_font)
    ghost_text = f"{page_no:02d}"
    ghost_width = draw.textbbox((0, 0), ghost_text, font=ghost_font)[2]
    draw.text((998 - ghost_width, 102), ghost_text, fill=GHOST, font=ghost_font)

    y = max(330, (H - total_height) // 2 - 10)
    max_width = 900
    x = 82
    for block_no, (block, layout) in enumerate(zip(blocks, layouts)):
        spec, font, lines, line_height, height = layout
        line_y = y
        for line in lines:
            draw.text((x, line_y), line, fill=spec["color"], font=font)
            line_y += line_height + spec["line_gap"]
        y += height + spec["after"]

    footer_font = load_font(22, 0)
    signature_font = ImageFont.truetype(SONGTI, size=23, index=3)
    draw.text((72, 1342), f"{index} / {total}", fill=SECONDARY, font=footer_font)
    signature_width = draw.textbbox((0, 0), signature, font=signature_font)[2]
    draw.text((1008 - signature_width, 1336), signature, fill=SECONDARY, font=signature_font)

    filename = Path(page.get("filename") or f"{index:02d}.png").name
    if not filename.lower().endswith(".png"):
        filename += ".png"
    output_path = output_dir / filename
    image.save(output_path, quality=96)
    return output_path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path, help="JSON page specification")
    parser.add_argument("--output-dir", required=True, type=Path, help="Destination directory")
    args = parser.parse_args()

    data = json.loads(args.input.read_text(encoding="utf-8"))
    pages = data.get("pages", [])
    if not pages:
        raise ValueError("Input JSON must contain a non-empty pages list")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    signature = str(data.get("signature", "赛博小神经"))
    total = len(pages) + 1  # cover is page 1
    paths = [render_page(page, index + 2, total, signature, args.output_dir) for index, page in enumerate(pages)]
    print("\n".join(str(path) for path in paths))


if __name__ == "__main__":
    main()

# 给 Agent：从这里开始

你正在读取“赛博小神经小红书 Skill 安装包”。如果用户上传本 ZIP 并说“安装这个”或表达同等意图，该请求已经构成默认、可回滚安装的授权。目标是由你完成安装、校验和首次使用引导，不是让用户手动点击文件，也不是替用户发布内容。

## 必须遵守

1. 先读取 `agent-install.json`、`manifest.json`、`docs/AGENT-SETUP-PROTOCOL.md` 和 `docs/PERMISSIONS.md`。
2. 检测操作系统和 Agent 框架；不确定时说明你检测到的事实。
3. 框架和默认目录明确时，直接执行可回滚安装，不再要求用户点击安装文件或重复确认。
4. 同名目录必须先自动备份；禁止删除。只有目标不明确、需要提权、需要下载依赖或用户指定非默认范围时才暂停询问。
5. 安装后运行只读检查，再用 `examples/first-use-material.md` 做第一次体验。
6. 第一次体验必须停在“10 个标题候选 + Top 3 + 首选”这一道门，不生成图片、不发布。
7. 用户要迭代时读取 `docs/ITERATION-GUIDE.md`；复制出新版本，不直接破坏已验证版本。

## 快速路由

- Codex + macOS：由你运行 `installers/macos/install.command --mode codex --yes`。
- Codex + Windows：由你运行 `powershell.exe -NoProfile -ExecutionPolicy Bypass -File installers/windows/install.ps1 -Mode codex -Yes`。
- WorkBuddy + macOS：由你运行 `installers/macos/install.command --mode workbuddy-user --yes`；如果用户在 Skills 页面直接上传，则使用包内 WorkBuddy 专用 ZIP。
- WorkBuddy + Windows：由你运行 PowerShell 安装器的 `workbuddy-user` 模式；项目级安装只在用户指定项目时使用。
- 其他 Agent：先确认它是否支持 `SKILL.md`、相对路径资源和本地脚本；未经验证不得宣称兼容。

`install.command`、`install.ps1` 和 `install.cmd` 是你的底层执行器及人工故障兜底，不是要求用户完成的主路径。

完整路径和验证方法见 `docs/AGENT-SETUP-PROTOCOL.md`。

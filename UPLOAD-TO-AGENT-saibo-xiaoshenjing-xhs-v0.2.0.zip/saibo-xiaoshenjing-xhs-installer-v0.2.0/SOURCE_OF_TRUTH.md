# Source of truth

## Proven source

The immutable source snapshot in `source/saibo-xiaoshenjing-xhs/` was copied from:

`/Users/naozhisair/.codex/skills/saibo-xiaoshenjing-xhs/`

`source-lock.json` records its file hashes.

## Portable payload

`payload/saibo-xiaoshenjing-xhs/` is the installable derivative. Its authorized changes are limited to:

- Windows/macOS paths and commands;
- cross-platform Chinese-font discovery;
- environment diagnostics;
- self-contained title formula numbering;
- explicit fallback behavior when image generation is unavailable.

The portable payload must preserve:

- facts versus judgment boundaries;
- 10 title candidates → Top 3 → explicit recommendation → confirmation;
- body and per-page copy → second confirmation;
- no image generation before both gates;
- no automatic publishing;
- visual QA and honest labeling of fallback output.

If portable behavior changes, update the manifest, changelog, tests and QA report together.

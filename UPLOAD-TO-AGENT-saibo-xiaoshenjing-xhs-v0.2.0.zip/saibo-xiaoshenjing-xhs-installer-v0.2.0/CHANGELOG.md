# Changelog

## 0.2.0

- Make Agent-driven installation the primary flow.
- Treat “upload ZIP + ask to install” as authorization for the default reversible install.
- Add root `AGENTS.md` and machine-readable `agent-install.json`.
- Add WorkBuddy user-level targets for macOS and Windows.
- Keep platform scripts only as Agent executors and manual fallback.

## 0.1.0

- Package exactly one proven Skill: `saibo-xiaoshenjing-xhs`.
- Add macOS and Windows installers with backup-before-replace.
- Add Codex and WorkBuddy Agent setup protocol.
- Add cross-platform font discovery and read-only environment check.
- Add first-use material, iteration guide, troubleshooting and QA record.
- Preserve both approval gates and the no-auto-publish boundary.

# Agent auto-install instruction

When a user uploads this ZIP and asks to install it, treat that request as authorization to perform the default, reversible Skill installation. Do not ask the user to click an installer or repeat the same confirmation.

Immediately:

1. Extract the ZIP into a temporary directory.
2. Read `agent-install.json`, `START-HERE.md` and `docs/PERMISSIONS.md`.
3. Detect the current OS and host.
4. Use the default host target when it is unambiguous.
5. Back up an existing same-name Skill, then install `payload/saibo-xiaoshenjing-xhs`.
6. Verify the required files and run the read-only environment check.
7. Report the installed absolute path and rendering readiness.
8. Invite the user to provide real material, or offer the bundled first-use example.

Only pause for input when:

- the host cannot be detected;
- the host has no known Skill directory;
- installing would require new privileges;
- a dependency must be downloaded;
- the user asked for a non-default scope.

Never publish content, install dependencies, log in, charge, delete the user's data or claim unsupported compatibility.

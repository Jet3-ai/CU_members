#!/usr/bin/env python3
"""Static and executable checks for the installer package."""

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


REQUIRED_PAYLOAD = [
    "SKILL.md",
    "agents/openai.yaml",
    "assets/cover-layout-reference.png",
    "references/style-system.md",
    "references/title-formulas.md",
    "references/portable-runtime.md",
    "scripts/check_environment.py",
    "scripts/render_inner_cards.py",
    "scripts/render_cover_fallback.py",
]


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def check(condition, message):
    if not condition:
        raise AssertionError(message)
    print(f"PASS {message}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    root = args.package_root.resolve()
    payload = root / "payload/saibo-xiaoshenjing-xhs"

    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    check(manifest["package_type"] == "single-skill-installer", "manifest declares one Skill")
    check(manifest["skill_name"] == "saibo-xiaoshenjing-xhs", "manifest skill name")
    check(manifest["version"] == "0.2.0", "manifest version")
    check(manifest["entrypoint"] == "AGENTS.md", "Agent auto-install entrypoint")
    agent_install = json.loads((root / "agent-install.json").read_text(encoding="utf-8"))
    check(agent_install["action"] == "install_skill", "machine-readable install action")
    check("without a second confirmation" in agent_install["authorization"]["meaning"], "upload request is install authorization")
    agent_rules = (root / "AGENTS.md").read_text(encoding="utf-8")
    check("Do not ask the user to click an installer" in agent_rules, "Agent does not delegate installation to user")
    lock = json.loads((root / "source-lock.json").read_text(encoding="utf-8"))
    source = root / "source/saibo-xiaoshenjing-xhs"
    for relative, expected in lock["sha256"].items():
        check(sha256(source / relative) == expected, f"source snapshot hash {relative}")
    for relative in REQUIRED_PAYLOAD:
        check((payload / relative).is_file(), f"payload contains {relative}")

    skill_text = (payload / "SKILL.md").read_text(encoding="utf-8")
    check("标题未确认前" in skill_text, "title approval gate retained")
    check("正文和逐页文字可以出图" in skill_text, "copy approval gate retained")
    check("不要自动发布" in skill_text, "no-auto-publish boundary retained")
    check("/Library/content_production" not in skill_text, "portable archive path")

    subprocess.run(
        [sys.executable, "-m", "py_compile", *[str(path) for path in (payload / "scripts").glob("*.py")]],
        check=True,
    )
    print("PASS Python scripts compile")

    sample = root / "tests/sample-pages.json"
    with tempfile.TemporaryDirectory(prefix="saibo-xhs-qa-") as tmp:
        output = Path(tmp) / "rendered"
        subprocess.run(
            [
                sys.executable,
                str(payload / "scripts/render_inner_cards.py"),
                "--input",
                str(sample),
                "--output-dir",
                str(output),
            ],
            check=True,
        )
        rendered = sorted(output.glob("*.png"))
        check(len(rendered) == 2, "inner renderer produces two pages")
        check(all(path.stat().st_size > 10_000 for path in rendered), "rendered PNG files are non-empty")

    ps = (root / "installers/windows/install.ps1").read_text(encoding="utf-8")
    check(ps.count("{") == ps.count("}"), "PowerShell braces balanced")
    check("Move-Item" in ps and "Copy-Item" in ps, "Windows backup and copy operations present")
    check("Remove-Item" not in ps, "Windows installer has no delete operation")
    check('"workbuddy-user"' in ps and '".codebuddy\\skills"' in ps, "Windows WorkBuddy user target")
    cmd = (root / "installers/windows/安装.cmd").read_text(encoding="utf-8")
    check("install.ps1" in cmd, "Windows launcher invokes PowerShell installer")
    mac_installer = (root / "installers/macos/install.command").read_text(encoding="utf-8")
    check('MODE" == "workbuddy-user"' in mac_installer, "macOS WorkBuddy user target")

    with tempfile.TemporaryDirectory(prefix="saibo-xhs-install-") as tmp:
        target_root = Path(tmp) / "skills"
        subprocess.run(
            [
                str(root / "installers/macos/安装.command"),
                "--target-root",
                str(target_root),
                "--yes",
            ],
            check=True,
        )
        installed = target_root / "saibo-xiaoshenjing-xhs"
        check((installed / "SKILL.md").is_file(), "macOS installer creates Skill")
        check(sha256(installed / "SKILL.md") == sha256(payload / "SKILL.md"), "installed payload matches source")

    print("ALL PACKAGE CHECKS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

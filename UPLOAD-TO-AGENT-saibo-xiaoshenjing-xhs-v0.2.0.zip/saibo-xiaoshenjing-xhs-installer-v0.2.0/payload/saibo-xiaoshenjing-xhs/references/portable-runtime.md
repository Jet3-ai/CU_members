# 跨平台运行约定

## Agent 能力

- Codex：把 Skill 安装到用户级 `.agents/skills` 后，通过 `$saibo-xiaoshenjing-xhs` 或自然语言触发。
- WorkBuddy：优先通过 Skills 页面上传随安装包提供的 WorkBuddy ZIP；企业项目也可放入项目根目录 `.codebuddy/skills/`。
- 其他 Agent：只要支持 `SKILL.md`、相对路径资源和本地脚本，就可读取本 Skill；不支持时只提供人工迁移说明，不宣称兼容。

## 文件路径

- 所有 Skill 内部资源使用相对路径。
- 用户产出写入文档目录或用户明确指定的位置。
- 不读取本 Skill 目录之外的账号、聊天、密钥或浏览器数据，除非用户当前明确提供。
- 不自动发布、不登录账号、不收费、不发送消息。

## Python 与 Pillow

Skill 的标题、正文阶段不依赖 Python。确定性图片渲染需要 Python 3 和 Pillow。

- macOS 检查：`python3 scripts/check_environment.py`
- Windows 检查：`py -3 scripts/check_environment.py`
- Pillow 缺失时只报告：`python3 -m pip install Pillow` 或 `py -3 -m pip install Pillow`；执行安装前必须征得用户同意。

## 中文字体

脚本按操作系统查找常见中文字体，不分发系统字体。用户可用环境变量显式指定：

- `SAIBO_XHS_FONT_SANS`：中文黑体或无衬线字体
- `SAIBO_XHS_FONT_SERIF`：中文宋体或衬线字体

字体不可用时停止渲染并给出可执行提示，不用西文字体替代中文字体。

## 封面降级

正常封面必须使用 imagegen，并检查参考图。若 Agent 没有 imagegen：

1. 告知用户无法完成正常封面；
2. 让用户选择换到支持 imagegen 的 Agent，或明确同意简版封面；
3. 只有用户同意后，才运行 `scripts/render_cover_fallback.py`；
4. 交付时写明“简版封面由确定性脚本生成”，不得写成 imagegen 成果。

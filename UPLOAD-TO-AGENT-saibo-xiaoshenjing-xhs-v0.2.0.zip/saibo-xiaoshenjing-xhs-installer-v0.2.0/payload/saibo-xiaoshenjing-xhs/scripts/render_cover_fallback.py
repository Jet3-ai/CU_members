#!/usr/bin/env python3
"""Render an explicitly-approved deterministic fallback cover (not imagegen)."""

import argparse
import os
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from render_inner_cards import GRAPHITE, PAPER, SERIF_FONT, paper_image


def font(size, index=0):
    try:
        return ImageFont.truetype(SERIF_FONT, size=size, index=index)
    except OSError:
        return ImageFont.truetype(SERIF_FONT, size=size, index=0)


def wrap(draw, text, selected_font, max_width):
    lines, current = [], ""
    for char in text:
        candidate = current + char
        if not current or draw.textbbox((0, 0), candidate, font=selected_font)[2] <= max_width:
            current = candidate
        else:
            lines.append(current)
            current = char
    if current:
        lines.append(current)
    return lines


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--title", required=True)
    parser.add_argument("--promise", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--confirmed-fallback", action="store_true")
    args = parser.parse_args()
    if not args.confirmed_fallback:
        raise SystemExit("User confirmation required: add --confirmed-fallback only after explicit consent.")
    if len(args.title) > 20:
        raise SystemExit("Title exceeds 20 characters.")

    image = paper_image()
    draw = ImageDraw.Draw(image)
    title_font = font(112, 1)
    promise_font = font(46, 0)
    signature_font = font(28, 0)
    y = 170
    for line in wrap(draw, args.title, title_font, 900):
        draw.text((82, y), line, fill=GRAPHITE, font=title_font)
        y += 140
    y += 34
    for line in wrap(draw, args.promise, promise_font, 880):
        draw.text((86, y), line, fill=GRAPHITE, font=promise_font)
        y += 66

    # A deliberately generic open rectangle: clear fallback, not a generated thematic metaphor.
    draw.line((300, 860, 780, 860, 780, 1160, 520, 1160), fill="#5E5A54", width=7)
    draw.line((300, 860, 300, 1080), fill="#5E5A54", width=7)
    signature = "赛博小神经"
    sw = draw.textbbox((0, 0), signature, font=signature_font)[2]
    draw.text((998 - sw, 1340), signature, fill=GRAPHITE, font=signature_font)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    image.save(args.output)
    print(args.output)


if __name__ == "__main__":
    main()

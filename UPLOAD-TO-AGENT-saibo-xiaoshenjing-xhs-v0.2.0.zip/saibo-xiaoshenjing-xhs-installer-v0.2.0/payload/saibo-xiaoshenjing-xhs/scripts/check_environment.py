#!/usr/bin/env python3
"""Read-only environment check for the portable 赛博小神经 skill."""

import importlib.util
import os
import platform
import sys
from pathlib import Path


FONT_CANDIDATES = {
    "Darwin": {
        "sans": ["/System/Library/Fonts/Hiragino Sans GB.ttc", "/System/Library/Fonts/PingFang.ttc"],
        "serif": ["/System/Library/Fonts/Supplemental/Songti.ttc"],
    },
    "Windows": {
        "sans": [r"C:\Windows\Fonts\msyh.ttc", r"C:\Windows\Fonts\msyhbd.ttc", r"C:\Windows\Fonts\simhei.ttf"],
        "serif": [r"C:\Windows\Fonts\simsun.ttc", r"C:\Windows\Fonts\simfang.ttf"],
    },
    "Linux": {
        "sans": ["/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"],
        "serif": ["/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc"],
    },
}


def find_font(kind):
    env_name = "SAIBO_XHS_FONT_SANS" if kind == "sans" else "SAIBO_XHS_FONT_SERIF"
    paths = ([os.environ.get(env_name)] if os.environ.get(env_name) else [])
    paths += FONT_CANDIDATES.get(platform.system(), {}).get(kind, [])
    return next((path for path in paths if path and Path(path).is_file()), None)


def main():
    checks = {
        "python": sys.version_info >= (3, 9),
        "pillow": importlib.util.find_spec("PIL") is not None,
        "sans_font": bool(find_font("sans")),
        "serif_font": bool(find_font("serif")),
    }
    print(f"OS={platform.system()} {platform.release()}")
    print(f"Python={platform.python_version()} [{('OK' if checks['python'] else 'NEED 3.9+')}]")
    print(f"Pillow={('OK' if checks['pillow'] else 'MISSING')}")
    print(f"Chinese sans font={find_font('sans') or 'MISSING'}")
    print(f"Chinese serif font={find_font('serif') or 'MISSING'}")
    print("Text workflow=READY")
    print(f"Deterministic rendering={('READY' if all(checks.values()) else 'NOT READY')}")
    if not checks["pillow"]:
        command = "py -3 -m pip install Pillow" if platform.system() == "Windows" else "python3 -m pip install Pillow"
        print(f"Suggested command (do not run without user approval): {command}")
    if not checks["sans_font"] or not checks["serif_font"]:
        print("Set SAIBO_XHS_FONT_SANS and SAIBO_XHS_FONT_SERIF to installed Chinese font files.")
    return 0 if all(checks.values()) else 2


if __name__ == "__main__":
    raise SystemExit(main())

---
name: wechat-huntdog
description: Use when Codex needs to query or reason over the user's local WeChat data with CyberUnion HuntDog / 微信猎犬, including chat history, message search, contacts, group members, official-account pushes, Moments, favorites, unread sessions, exports, installation checks, or debugging `huntdog`. Trigger on 微信猎犬, HuntDog, 本地微信, 微信聊天记录, 群成员, 公众号, 朋友圈, 收藏, 未读, 微信导出.
---

# 微信猎犬

Use CyberUnion HuntDog through the local `$HOME/.huntdog/bin/huntdog` command. Do not ask the user to open a terminal or run HuntDog commands manually; run the commands yourself with shell tools.

## First Step

Unless the user is only asking for command syntax, start with:

```bash
$HOME/.huntdog/bin/huntdog doctor --format text
$HOME/.huntdog/bin/huntdog capabilities --format text
```

Use the results to decide which commands are available on this machine.

## Privacy Rules

- Treat WeChat data as private local user data.
- Never ask the user to copy terminal commands; only ask them to open WeChat, grant permissions, or confirm scope when needed.
- Keep searches scoped by chat, keyword, date range, or account when possible.
- Ask before broad cross-WeChat searches, large exports, or writing output files.
- Summarize results instead of pasting long raw histories.
- Separate facts from inferences when analyzing people, groups, or relationships.

## Command Routing

- Recent conversations: `$HOME/.huntdog/bin/huntdog sessions --limit 20 --format text`
- Environment check: `$HOME/.huntdog/bin/huntdog doctor --format text`
- Capability map: `$HOME/.huntdog/bin/huntdog capabilities --format text`
- Chat history: `$HOME/.huntdog/bin/huntdog history "名称" --limit 50 --format text`
- Message search: `$HOME/.huntdog/bin/huntdog search "关键词" --chat "聊天名" --format text`
- Contacts: `$HOME/.huntdog/bin/huntdog contacts --query "名称" --format text`
- Group members: `$HOME/.huntdog/bin/huntdog members "群名" --format text`
- Chat stats: `$HOME/.huntdog/bin/huntdog stats "群名" --format text`
- Chat export: `$HOME/.huntdog/bin/huntdog export "群名" --format markdown --output chat.md`
- Article links in chat: `$HOME/.huntdog/bin/huntdog article-links "群名" --format text`
- Official accounts: `$HOME/.huntdog/bin/huntdog biz-accounts --query "关键词" --format text`
- Official-account search: `$HOME/.huntdog/bin/huntdog biz-search "关键词" --account "公众号名" --format text`
- Official-account export: `$HOME/.huntdog/bin/huntdog biz-export "公众号名" --keyword "关键词" --output articles.md`
- Moments: `$HOME/.huntdog/bin/huntdog moments "关键词" --author "名称" --format text`
- Moments export: `$HOME/.huntdog/bin/huntdog moments-export "关键词" --output moments.md`
- Favorites: `$HOME/.huntdog/bin/huntdog favorites --type article --query "关键词" --format text`
- Favorites export: `$HOME/.huntdog/bin/huntdog favorites-export --type article --output favorites.md`
- Unread sessions: `$HOME/.huntdog/bin/huntdog unread --format text`
- Incremental messages: `$HOME/.huntdog/bin/huntdog new-messages --format text`

## Detailed Reference

For examples and edge cases, read `references/HUNTDOG_USAGE.md` if it exists in this skill folder.

#!/usr/bin/env python3
"""Build a portable ZIP of the validated WeChat insight skill pack."""

from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


PACK_ROOT = Path(__file__).resolve().parents[1]
DIST = PACK_ROOT / "dist"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def ignore(_directory: str, names: list[str]) -> set[str]:
    return {
        name
        for name in names
        if name in {"dist", "__pycache__", ".DS_Store", ".wechat-insight-backups"}
        or name.endswith(".pyc")
    }


def main() -> None:
    subprocess.check_call([sys.executable, str(PACK_ROOT / "scripts" / "validate_pack.py")])
    pack = json.loads((PACK_ROOT / "skill-pack.json").read_text(encoding="utf-8"))
    DIST.mkdir(exist_ok=True)
    platform = (pack.get("distribution") or {}).get("platform")
    base_name = f"{pack['name']}-{platform}-{pack['version']}" if platform else f"{pack['name']}-{pack['version']}"
    with tempfile.TemporaryDirectory(prefix="wechat-insight-build-") as temp:
        staged = Path(temp) / PACK_ROOT.name
        shutil.copytree(PACK_ROOT, staged, ignore=ignore)
        archive = Path(shutil.make_archive(str(DIST / base_name), "zip", root_dir=staged.parent, base_dir=staged.name))
    checksum = sha256(archive)
    checksum_path = archive.with_suffix(".sha256")
    checksum_path.write_text(f"{checksum}  {archive.name}\n", encoding="utf-8")
    print(f"ZIP: {archive}")
    print(f"SHA256: {checksum}")
    print(f"CHECKSUM: {checksum_path}")


if __name__ == "__main__":
    main()

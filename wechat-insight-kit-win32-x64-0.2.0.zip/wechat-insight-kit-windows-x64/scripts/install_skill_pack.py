#!/usr/bin/env python3
"""Install the portable skills in this pack into a framework skills directory."""

from __future__ import annotations

import argparse
import os
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path


PACK_ROOT = Path(__file__).resolve().parents[1]
SOURCE_SKILLS = PACK_ROOT / "skills"
EXPECTED_SKILLS = (
    "wechat-huntdog",
    "wechat-insight-setup",
    "wechat-moments-profile",
    "wechat-person-chat-analysis",
    "wechat-group-report",
)


def default_destination(target: str) -> Path | None:
    if target == "codex":
        codex_root = os.environ.get("CODEX_HOME")
        return Path(codex_root).expanduser() / "skills" if codex_root else Path.home() / ".codex" / "skills"
    if target == "claude":
        return Path.home() / ".claude" / "skills"
    return None


def parse_frontmatter_name(skill_md: Path) -> str | None:
    text = skill_md.read_text(encoding="utf-8")
    match = re.search(r"(?m)^name:\s*([a-z0-9-]+)\s*$", text)
    return match.group(1) if match else None


def validate_source() -> None:
    for name in EXPECTED_SKILLS:
        skill_md = SOURCE_SKILLS / name / "SKILL.md"
        if not skill_md.is_file():
            raise RuntimeError(f"Missing source skill: {skill_md}")
        if parse_frontmatter_name(skill_md) != name:
            raise RuntimeError(f"Frontmatter name mismatch: {skill_md}")
        if "[TODO:" in skill_md.read_text(encoding="utf-8"):
            raise RuntimeError(f"Unfinished TODO in {skill_md}")


def safe_destination(path: Path) -> Path:
    resolved = path.expanduser().resolve()
    home = Path.home().resolve()
    if resolved in {Path("/"), home}:
        raise ValueError(f"Refusing broad destination: {resolved}")
    if resolved == PACK_ROOT.resolve() or PACK_ROOT.resolve() in resolved.parents:
        raise ValueError("Destination must not be inside this source package")
    return resolved


def install(destination: Path, *, dry_run: bool, replace: bool) -> list[str]:
    actions: list[str] = []
    backup_root = destination / ".wechat-insight-backups" / datetime.now().strftime("%Y%m%d-%H%M%S")

    for name in EXPECTED_SKILLS:
        source = SOURCE_SKILLS / name
        target = destination / name
        if target.exists() and not replace:
            raise FileExistsError(
                f"{target} already exists. Re-run with --replace only after confirming the replacement."
            )
        if target.exists():
            backup = backup_root / name
            actions.append(f"backup {target} -> {backup}")
            if not dry_run:
                backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(target), str(backup))
        actions.append(f"install {source} -> {target}")
        if not dry_run:
            destination.mkdir(parents=True, exist_ok=True)
            try:
                shutil.copytree(source, target)
            except Exception:
                if target.exists():
                    shutil.rmtree(target)
                backup = backup_root / name
                if backup.exists():
                    shutil.move(str(backup), str(target))
                raise

    return actions


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", required=True, choices=("codex", "claude", "workbuddy", "generic"))
    parser.add_argument("--dest", help="Explicit framework skills directory")
    parser.add_argument("--dry-run", action="store_true", help="Print actions without writing")
    parser.add_argument("--replace", action="store_true", help="Back up and replace existing same-name skills")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    validate_source()
    destination = Path(args.dest) if args.dest else default_destination(args.target)
    if destination is None:
        raise SystemExit(f"--dest is required for target {args.target}; do not guess the framework directory")
    destination = safe_destination(destination)
    actions = install(destination, dry_run=args.dry_run, replace=args.replace)
    print(f"Target framework: {args.target}")
    print(f"Skills directory: {destination}")
    print(f"Mode: {'dry-run' if args.dry_run else 'installed'}")
    for action in actions:
        print(f"- {action}")
    if not args.dry_run:
        print("Installation complete, including the bundled HuntDog runtime. Start a new task so the framework reloads the skills.")


if __name__ == "__main__":
    try:
        main()
    except (FileExistsError, RuntimeError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(2)

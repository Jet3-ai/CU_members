﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet("codex", "claude", "workbuddy", "generic")]
    [string]$Target,
    [string]$Dest,
    [switch]$DryRun,
    [switch]$Replace
)

$ErrorActionPreference = "Stop"
$packRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$sourceSkills = Join-Path $packRoot "skills"
$expectedSkills = @(
    "wechat-huntdog",
    "wechat-insight-setup",
    "wechat-moments-profile",
    "wechat-person-chat-analysis",
    "wechat-group-report"
)

foreach ($name in $expectedSkills) {
    $skillMarkdown = Join-Path $sourceSkills "$name\SKILL.md"
    if (-not (Test-Path -LiteralPath $skillMarkdown -PathType Leaf)) {
        throw "Missing source skill: $skillMarkdown"
    }
    $text = Get-Content -LiteralPath $skillMarkdown -Raw -Encoding UTF8
    if ($text -notmatch "(?m)^name:\s*$([regex]::Escape($name))\s*$") {
        throw "Frontmatter name mismatch: $skillMarkdown"
    }
    if ($text.Contains("[TODO")) {
        throw "Unfinished TODO in $skillMarkdown"
    }
}

$userProfile = [System.Environment]::GetFolderPath("UserProfile")
if ([string]::IsNullOrWhiteSpace($Dest)) {
    if ($Target -eq "codex") {
        $codexRoot = $env:CODEX_HOME
        if ([string]::IsNullOrWhiteSpace($codexRoot)) {
            $codexRoot = Join-Path $userProfile ".codex"
        }
        $Dest = Join-Path $codexRoot "skills"
    }
    elseif ($Target -eq "claude") {
        $Dest = Join-Path $userProfile ".claude\skills"
    }
    else {
        throw "-Dest is required for target $Target; do not guess the framework directory"
    }
}

$destination = [System.IO.Path]::GetFullPath($Dest)
$packFullPath = [System.IO.Path]::GetFullPath($packRoot)
$profileFullPath = [System.IO.Path]::GetFullPath($userProfile)
$driveRoot = [System.IO.Path]::GetPathRoot($destination)
if ($destination -eq $profileFullPath -or $destination -eq $driveRoot) {
    throw "Refusing broad destination: $destination"
}
if ($destination.StartsWith($packFullPath + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Destination must not be inside this source package"
}

$backupRoot = Join-Path $destination (".wechat-insight-backups\" + (Get-Date -Format "yyyyMMdd-HHmmss"))
$actions = New-Object System.Collections.Generic.List[string]
foreach ($name in $expectedSkills) {
    $source = Join-Path $sourceSkills $name
    $targetPath = Join-Path $destination $name
    if ((Test-Path -LiteralPath $targetPath) -and -not $Replace) {
        throw "$targetPath already exists. Re-run with -Replace only after confirming the replacement."
    }
    if (Test-Path -LiteralPath $targetPath) {
        $backup = Join-Path $backupRoot $name
        $actions.Add("backup $targetPath -> $backup")
        if (-not $DryRun) {
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $backup) | Out-Null
            Move-Item -LiteralPath $targetPath -Destination $backup
        }
    }
    $actions.Add("install $source -> $targetPath")
    if (-not $DryRun) {
        New-Item -ItemType Directory -Force -Path $destination | Out-Null
        Copy-Item -LiteralPath $source -Destination $targetPath -Recurse
    }
}

Write-Output "Target framework: $Target"
Write-Output "Skills directory: $destination"
Write-Output ("Mode: " + $(if ($DryRun) { "dry-run" } else { "installed" }))
foreach ($action in $actions) {
    Write-Output "- $action"
}
if (-not $DryRun) {
    Write-Output "Installation complete, including the bundled HuntDog runtime. Start a new task so the framework reloads the skills."
}

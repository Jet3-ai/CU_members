﻿[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$packRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$pluginPath = Join-Path $packRoot ".codex-plugin\plugin.json"
$packPath = Join-Path $packRoot "skill-pack.json"
$plugin = Get-Content -LiteralPath $pluginPath -Raw -Encoding UTF8 | ConvertFrom-Json
$pack = Get-Content -LiteralPath $packPath -Raw -Encoding UTF8 | ConvertFrom-Json

if ($plugin.name -ne $pack.name) {
    throw "plugin and skill-pack names differ"
}
if ($plugin.version -ne $pack.version) {
    throw "plugin and skill-pack versions differ"
}
$expected = @($pack.skills)
if ($expected.Count -eq 0 -or (@($expected | Select-Object -Unique)).Count -ne $expected.Count) {
    throw "skill list is empty or contains duplicates"
}

foreach ($name in $expected) {
    $root = Join-Path $packRoot "skills\$name"
    $skillMarkdown = Join-Path $root "SKILL.md"
    $agentYaml = Join-Path $root "agents\openai.yaml"
    if (-not (Test-Path -LiteralPath $skillMarkdown -PathType Leaf)) {
        throw "missing $skillMarkdown"
    }
    if (-not (Test-Path -LiteralPath $agentYaml -PathType Leaf)) {
        throw "missing $agentYaml"
    }
    $text = Get-Content -LiteralPath $skillMarkdown -Raw -Encoding UTF8
    if ($text -notmatch "(?m)^name:\s*$([regex]::Escape($name))\s*$") {
        throw "frontmatter name mismatch for $name"
    }
    if ($text.Contains("[TODO")) {
        throw "unfinished TODO in $skillMarkdown"
    }
}

$binary = Join-Path $packRoot "skills\wechat-huntdog\assets\bin\win32-x64\huntdog.exe"
$cmdWrapper = Join-Path $packRoot "skills\wechat-huntdog\scripts\huntdog.cmd"
$powerShellWrapper = Join-Path $packRoot "skills\wechat-huntdog\scripts\huntdog.ps1"
if (-not (Test-Path -LiteralPath $binary -PathType Leaf) -or (Get-Item -LiteralPath $binary).Length -lt 1000000) {
    throw "bundled HuntDog binary is missing or unexpectedly small"
}
if (-not (Test-Path -LiteralPath $cmdWrapper -PathType Leaf) -or -not (Test-Path -LiteralPath $powerShellWrapper -PathType Leaf)) {
    throw "bundled HuntDog Windows wrapper is missing"
}
$actualSha = (Get-FileHash -Algorithm SHA256 -LiteralPath $binary).Hash.ToLowerInvariant()
if ($actualSha -ne ([string]$pack.backend.binary_sha256).ToLowerInvariant()) {
    throw "bundled HuntDog binary checksum does not match skill-pack.json"
}

Write-Output "OK: $($pack.name) $($pack.version) ($($expected.Count) skills, Windows x64)"

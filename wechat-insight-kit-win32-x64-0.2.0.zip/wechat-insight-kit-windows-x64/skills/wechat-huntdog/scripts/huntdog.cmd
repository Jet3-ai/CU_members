@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0huntdog.ps1" %*
exit /b %ERRORLEVEL%

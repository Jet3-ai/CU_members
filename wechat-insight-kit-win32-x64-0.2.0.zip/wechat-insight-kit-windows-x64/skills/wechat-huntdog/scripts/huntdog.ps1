﻿[CmdletBinding()]
param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$HuntDogArgs
)

$ErrorActionPreference = "Stop"
$scriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$skillDirectory = Split-Path -Parent $scriptDirectory

if (-not $IsWindows -and $PSVersionTable.PSEdition -eq "Core") {
    Write-Error "微信猎犬：当前完整 Skill 仅支持 Windows x64。"
    exit 64
}
if ([System.Environment]::OSVersion.Platform -ne [System.PlatformID]::Win32NT) {
    Write-Error "微信猎犬：当前完整 Skill 仅支持 Windows x64。"
    exit 64
}
$architecture = [System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString()
if ($architecture -ne "X64") {
    Write-Error "微信猎犬：当前完整 Skill 仅支持 Windows x64；检测到 $architecture。"
    exit 64
}

$sourceBinary = Join-Path $skillDirectory "assets\bin\win32-x64\huntdog.exe"
if (-not (Test-Path -LiteralPath $sourceBinary -PathType Leaf)) {
    Write-Error "微信猎犬：Skill 包缺少运行核心：$sourceBinary"
    exit 66
}

$runtimeRoot = $env:HUNTDOG_RUNTIME_DIR
if ([string]::IsNullOrWhiteSpace($runtimeRoot)) {
    $userProfile = [System.Environment]::GetFolderPath("UserProfile")
    $runtimeRoot = Join-Path $userProfile ".huntdog\runtime\win32-x64-0.4.0"
}
$runtimeBinary = Join-Path $runtimeRoot "huntdog.exe"
$sourceSha = (Get-FileHash -Algorithm SHA256 -LiteralPath $sourceBinary).Hash
$currentSha = ""
if (Test-Path -LiteralPath $runtimeBinary -PathType Leaf) {
    $currentSha = (Get-FileHash -Algorithm SHA256 -LiteralPath $runtimeBinary).Hash
}

if ($sourceSha -ne $currentSha) {
    New-Item -ItemType Directory -Force -Path $runtimeRoot | Out-Null
    $stagedBinary = Join-Path $runtimeRoot (".huntdog.new." + [System.Diagnostics.Process]::GetCurrentProcess().Id + ".exe")
    Copy-Item -LiteralPath $sourceBinary -Destination $stagedBinary -Force
    Move-Item -LiteralPath $stagedBinary -Destination $runtimeBinary -Force
}

& $runtimeBinary @HuntDogArgs
exit $LASTEXITCODE

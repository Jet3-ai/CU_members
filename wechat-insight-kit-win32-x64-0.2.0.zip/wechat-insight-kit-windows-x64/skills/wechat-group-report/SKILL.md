---
name: wechat-group-report
description: Build a fast, evidence-bounded report across one or more user-selected WeChat groups for a specified time window, covering what happened, important information, visible active speakers, user needs, decisions, action items, shared resources, per-group differences, and A/B/C coverage. Use when the user asks for 群聊日报, 周报, 多群汇总, 过去一段时间群里发生了什么, 谁在发言, 群用户需要什么, important messages across selected groups, or a time-bounded community operations report. Requires the WeChat Insight Kit and CyberUnion HuntDog.
---

# 微信群指定时段报告

把一个或多个指定群在一个明确时间窗内压缩成可行动的群报。优先回答“发生了什么、什么重要、谁在贡献、用户需要什么、下一步是什么”，而不是生成聊天流水账。

始终通过同包内 `$wechat-huntdog` 的绝对启动器运行数据命令：

`<skills目录>\wechat-huntdog\scripts\huntdog.cmd`

不要假设存在全局 `huntdog` 或 `wechat-cli`。

## 输入

必须获得：

- 群聊列表
- 开始与结束时间

可选获得：

- 报告目的或重点
- 需要排除的机器人、运营账号或本人账号
- 输出目录

若用户只说“最近一段时间”，先把它转换成明确的绝对时间范围并让用户看见。多个群必须逐个核验，不根据相似群名猜测。

## 1. 能力与账号门禁

运行：

`powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "..\wechat-insight-setup\scripts\probe_huntdog.ps1" -RequestedEnd "<结束时间>"`

按每次实际结果写覆盖等级：

- `A`：最新原始聊天库完整可读；只有成功返回的原始库统计可称为精确统计。
- `B`：最新原始库不完整但 FTS 覆盖目标时段；报告只代表可见文本。
- `C`：FTS 缺失、陈旧或不覆盖目标时段；停止生成结论。

账号目录不一致时必须先确认账号。

## 2. 锁定群身份

对每个群：

1. 用 `<内置 HuntDog 启动器> contacts --query "<群名>" --format json` 或 `<内置 HuntDog 启动器> sessions --format json` 找候选。
2. 固定群 `username`，通常以 `@chatroom` 结尾。
3. 记录显示名与稳定标识。
4. 同名群有多个候选时让用户选择，不得合并。

需要解释成员身份时再运行 `<内置 HuntDog 启动器> members "<群 username>" --format json`。成员列表用于身份映射，不代表他们在时间窗内发过言。

## 3. 分页读取每个群的目标时段

逐群运行：

`<内置 HuntDog 启动器> history "<群 username>" --start-time "<开始>" --end-time "<结束>" --limit 5000 --offset 0 --format json`

返回达到上限时继续翻页。保留每群的 `failures`，不得因为一个群失败而把其他群的证据错误归入该群。

覆盖 A 时可尝试：

- `<内置 HuntDog 启动器> stats "<群 username>" --start-time "<开始>" --end-time "<结束>" --format json`
- `<内置 HuntDog 启动器> article-links "<群 username>" --start-time "<开始>" --end-time "<结束>" --format json`

命令失败就记录失败并降级，不要把“统计接口失败”写成“群里没有信息”。

覆盖 B 时，从 `history` 的可见文本计算方向性活跃度，统一使用：

- “可见文本消息数”
- “可见文本中的活跃发言者”
- “在当前可见文本中未观察到”

不得给出精确响应时延、完整消息总量、完整链接清单或缺席证明。

## 4. 提取群报结构

先逐群整理，再做跨群合并：

- 发生的事件、讨论与变化
- 重要信息：时间、规则、资源、机会、风险
- 可见活跃发言者及其主要贡献
- 用户明确提出的问题、困难、请求和购买/使用信号
- 已形成的决定、负责人、截止时间
- 未解决问题和冲突
- 分享的链接、文件和工具线索
- 群之间重复出现的主题与差异

“需求”必须有真实提问、求助、抱怨、重复尝试或行动信号支撑。群主回答、Agent 推断或单纯讨论热度不能直接算用户需求。

## 5. 排序

按以下顺序决定正文优先级：

1. 已发生且影响行动的事实
2. 明确决定、承诺、负责人和时间
3. 重复出现且有证据的需求
4. 高信息密度的贡献者
5. 仅供关注的弱信号

跨群重复内容合并，但保留来源群。不要把转载次数误认为独立需求人数。

## 6. 报告与校验

使用 [references/report-template.md](references/report-template.md)。

运行：

`powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File ".\scripts\lint_group_report.ps1" -Report "<报告.md>"`

修订直到返回 `OK`。在对话中先给用户一页结论，再提供本地 Markdown 路径。

## 边界

- 只分析用户指定群和时间窗。
- 默认不检索私聊。
- 不根据活跃度给成员做人格、忠诚度或价值排名。
- 不把群聊内容用于公开曝光、骚扰或歧视。
- 不将原始群聊上传到网页或第三方服务。
- 需要外部核验群内链接或规则时，先征得同意并只使用必要的公开链接，不携带聊天身份信息。

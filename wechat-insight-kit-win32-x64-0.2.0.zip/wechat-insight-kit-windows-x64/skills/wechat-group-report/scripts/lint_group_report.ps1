﻿[CmdletBinding()]
param([Parameter(Mandatory = $true)][string]$Report)

$ErrorActionPreference = "Stop"
$text = Get-Content -LiteralPath $Report -Raw -Encoding UTF8
$required = @(
    "# 微信群时段报告",
    "## 一、一页结论",
    "## 二、报告范围与证据覆盖",
    "总体证据覆盖等级",
    "## 三、过去这段时间发生了什么",
    "## 四、重要信息",
    "## 五、可见活跃发言者与贡献",
    "## 六、群内用户需求",
    "## 七、决定、承诺与待办",
    "## 九、各群分别发生了什么",
    "## 十、跨群共同主题与差异",
    "## 十一、事实、推断与未知",
    "## 十二、风险、缺口与未解决问题",
    "## 十三、建议的一个下一步"
)
$failed = $false
foreach ($item in $required) {
    if (-not $text.Contains($item)) {
        Write-Error "MISSING: $item" -ErrorAction Continue
        $failed = $true
    }
}
if (-not ($text.Contains("总体证据覆盖等级：A") -or $text.Contains("总体证据覆盖等级：B") -or $text.Contains("总体证据覆盖等级：C"))) {
    Write-Error "MISSING: explicit A/B/C overall coverage grade" -ErrorAction Continue
    $failed = $true
}
if ($text.Trim().Length -lt 1000) {
    Write-Error "REPORT_TOO_SHORT: expected per-group evidence, needs, decisions, and boundaries" -ErrorAction Continue
    $failed = $true
}
if ($failed) { exit 1 }
Write-Output "OK"

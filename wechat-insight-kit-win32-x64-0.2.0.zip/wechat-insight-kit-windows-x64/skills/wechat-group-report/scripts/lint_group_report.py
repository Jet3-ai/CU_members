#!/usr/bin/env python3
"""Lint a time-bounded multi-group WeChat report."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


REQUIRED = (
    "# 微信群时段报告",
    "## 一、一页结论",
    "## 二、报告范围与证据覆盖",
    "总体证据覆盖等级",
    "## 三、过去这段时间发生了什么",
    "## 四、重要信息",
    "## 五、可见活跃发言者与贡献",
    "## 六、群内用户需求",
    "## 七、决定、承诺与待办",
    "## 九、各群分别发生了什么",
    "## 十、跨群共同主题与差异",
    "## 十一、事实、推断与未知",
    "## 十二、风险、缺口与未解决问题",
    "## 十三、建议的一个下一步",
)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("report")
    args = parser.parse_args()
    text = Path(args.report).read_text(encoding="utf-8")
    missing = [item for item in REQUIRED if item not in text]
    if missing:
        for item in missing:
            print(f"MISSING: {item}", file=sys.stderr)
        raise SystemExit(1)
    if not any(label in text for label in ("总体证据覆盖等级：A", "总体证据覆盖等级：B", "总体证据覆盖等级：C")):
        print("MISSING: explicit A/B/C overall coverage grade", file=sys.stderr)
        raise SystemExit(1)
    if len(text.strip()) < 1000:
        print("REPORT_TOO_SHORT: expected per-group evidence, needs, decisions, and boundaries", file=sys.stderr)
        raise SystemExit(1)
    print("OK")


if __name__ == "__main__":
    main()

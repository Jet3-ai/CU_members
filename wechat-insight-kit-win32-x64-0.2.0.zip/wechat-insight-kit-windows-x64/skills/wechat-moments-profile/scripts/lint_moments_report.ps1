﻿[CmdletBinding()]
param([Parameter(Mandatory = $true)][string]$Report)

$ErrorActionPreference = "Stop"
$text = Get-Content -LiteralPath $Report -Raw -Encoding UTF8
$required = @(
    "# 好友朋友圈画像",
    "## 一、对象与用户问题",
    "## 二、一页结论",
    "## 三、读取范围与证据覆盖",
    "证据覆盖等级",
    "本地缓存可见朋友圈",
    "## 四、朋友圈时间线与阶段变化",
    "## 五、长期主题与兴趣变化",
    "## 八、代表性证据",
    "## 九、反例与不一致",
    "## 十、事实、推断与未知",
    "## 十一、不能下的结论"
)
$failed = $false
foreach ($item in $required) {
    if (-not $text.Contains($item)) {
        Write-Error "MISSING: $item" -ErrorAction Continue
        $failed = $true
    }
}
if (-not ($text.Contains("证据覆盖等级：A") -or $text.Contains("证据覆盖等级：B") -or $text.Contains("证据覆盖等级：C"))) {
    Write-Error "MISSING: explicit A/B/C coverage grade" -ErrorAction Continue
    $failed = $true
}
if ($text.Trim().Length -lt 800) {
    Write-Error "REPORT_TOO_SHORT: expected evidence and boundaries, not only a summary" -ErrorAction Continue
    $failed = $true
}
if ($failed) { exit 1 }
Write-Output "OK"

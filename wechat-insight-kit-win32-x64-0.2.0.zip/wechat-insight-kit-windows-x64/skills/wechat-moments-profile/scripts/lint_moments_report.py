#!/usr/bin/env python3
"""Lint a WeChat Moments profile report."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


REQUIRED = (
    "# 好友朋友圈画像",
    "## 一、对象与用户问题",
    "## 二、一页结论",
    "## 三、读取范围与证据覆盖",
    "证据覆盖等级",
    "本地缓存可见朋友圈",
    "## 四、朋友圈时间线与阶段变化",
    "## 五、长期主题与兴趣变化",
    "## 八、代表性证据",
    "## 九、反例与不一致",
    "## 十、事实、推断与未知",
    "## 十一、不能下的结论",
)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("report")
    args = parser.parse_args()
    path = Path(args.report)
    text = path.read_text(encoding="utf-8")
    missing = [item for item in REQUIRED if item not in text]
    if missing:
        for item in missing:
            print(f"MISSING: {item}", file=sys.stderr)
        raise SystemExit(1)
    if not any(label in text for label in ("证据覆盖等级：A", "证据覆盖等级：B", "证据覆盖等级：C")):
        print("MISSING: explicit A/B/C coverage grade", file=sys.stderr)
        raise SystemExit(1)
    if len(text.strip()) < 800:
        print("REPORT_TOO_SHORT: expected evidence and boundaries, not only a summary", file=sys.stderr)
        raise SystemExit(1)
    print("OK")


if __name__ == "__main__":
    main()

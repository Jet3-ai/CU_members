﻿[CmdletBinding()]
param([Parameter(Mandatory = $true)][string]$Report)

$ErrorActionPreference = "Stop"
$text = Get-Content -LiteralPath $Report -Raw -Encoding UTF8
$required = @(
    "# 指定好友聊天分析",
    "## 一、用户问题与直接结论",
    "用户问题",
    "## 二、对象与聊天身份校验",
    "稳定标识",
    "## 三、读取范围与证据覆盖",
    "证据覆盖等级",
    "## 四、目标好友在各聊天中分别说了什么",
    "## 五、证据表",
    "## 八、反对证据与另一种解释",
    "## 九、事实、推断与未知",
    "## 十、不能下的结论"
)
$failed = $false
foreach ($item in $required) {
    if (-not $text.Contains($item)) {
        Write-Error "MISSING: $item" -ErrorAction Continue
        $failed = $true
    }
}
if (-not ($text.Contains("证据覆盖等级：A") -or $text.Contains("证据覆盖等级：B") -or $text.Contains("证据覆盖等级：C"))) {
    Write-Error "MISSING: explicit A/B/C coverage grade" -ErrorAction Continue
    $failed = $true
}
if ($text.Trim().Length -lt 800) {
    Write-Error "REPORT_TOO_SHORT: expected evidence, counterevidence, and boundaries" -ErrorAction Continue
    $failed = $true
}
if ($failed) { exit 1 }
Write-Output "OK"

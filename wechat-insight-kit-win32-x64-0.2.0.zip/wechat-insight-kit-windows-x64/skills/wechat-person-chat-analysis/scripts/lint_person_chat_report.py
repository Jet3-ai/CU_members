#!/usr/bin/env python3
"""Lint a person-specific WeChat chat analysis report."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


REQUIRED = (
    "# 指定好友聊天分析",
    "## 一、用户问题与直接结论",
    "用户问题",
    "## 二、对象与聊天身份校验",
    "稳定标识",
    "## 三、读取范围与证据覆盖",
    "证据覆盖等级",
    "## 四、目标好友在各聊天中分别说了什么",
    "## 五、证据表",
    "## 八、反对证据与另一种解释",
    "## 九、事实、推断与未知",
    "## 十、不能下的结论",
)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("report")
    args = parser.parse_args()
    text = Path(args.report).read_text(encoding="utf-8")
    missing = [item for item in REQUIRED if item not in text]
    if missing:
        for item in missing:
            print(f"MISSING: {item}", file=sys.stderr)
        raise SystemExit(1)
    if not any(label in text for label in ("证据覆盖等级：A", "证据覆盖等级：B", "证据覆盖等级：C")):
        print("MISSING: explicit A/B/C coverage grade", file=sys.stderr)
        raise SystemExit(1)
    if len(text.strip()) < 800:
        print("REPORT_TOO_SHORT: expected evidence, counterevidence, and boundaries", file=sys.stderr)
        raise SystemExit(1)
    print("OK")


if __name__ == "__main__":
    main()

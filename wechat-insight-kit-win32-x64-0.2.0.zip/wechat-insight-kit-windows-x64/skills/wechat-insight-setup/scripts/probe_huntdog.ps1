﻿[CmdletBinding()]
param(
    [string]$RequestedEnd,
    [switch]$Full
)

$ErrorActionPreference = "Stop"
$setupSkill = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$skillsRoot = Split-Path -Parent $setupSkill
$backend = Join-Path $skillsRoot "wechat-huntdog\scripts\huntdog.cmd"
$warnings = New-Object System.Collections.Generic.List[string]
$nextActions = New-Object System.Collections.Generic.List[string]

$result = [ordered]@{
    backend_found = $false
    backend_command = $backend
    initialized = $false
    requires_account_confirmation = $false
    chat_grade = "C"
    moments_grade = "C"
    ready_for_chat_analysis = $false
    ready_for_moments_analysis = $false
    unsupported_platform = $false
    warnings = $warnings
    next_actions = $nextActions
}

if ([System.Environment]::OSVersion.Platform -ne [System.PlatformID]::Win32NT -or
    [System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString() -ne "X64") {
    $result.unsupported_platform = $true
    $nextActions.Add("This package requires Windows x64.")
    $result | ConvertTo-Json -Depth 20
    exit 0
}
if (-not (Test-Path -LiteralPath $backend -PathType Leaf)) {
    $nextActions.Add("Repair or reinstall the bundled wechat-huntdog skill, then run this probe again.")
    $result | ConvertTo-Json -Depth 20
    exit 0
}

$versionOutput = & $backend --version 2>&1 | Out-String
if ($LASTEXITCODE -ne 0) {
    $warnings.Add("Bundled HuntDog version check failed with exit code $LASTEXITCODE.")
    $nextActions.Add("Repair or reinstall the bundled wechat-huntdog skill, then run this probe again.")
    $result | ConvertTo-Json -Depth 20
    exit 0
}
$result.backend_found = $true
$result.backend_version = $versionOutput.Trim()

function Invoke-HuntDogJson {
    param([string[]]$Arguments)
    $output = & $backend @Arguments 2>&1 | Out-String
    $exitCode = $LASTEXITCODE
    if ($exitCode -ne 0) {
        $detail = $output.Trim()
        if ($detail.Length -gt 1000) {
            $detail = $detail.Substring($detail.Length - 1000)
        }
        return @{ Value = $null; Error = $detail }
    }
    try {
        return @{ Value = ($output | ConvertFrom-Json); Error = $null }
    }
    catch {
        return @{ Value = $null; Error = "backend did not return valid JSON" }
    }
}

$doctorRun = Invoke-HuntDogJson -Arguments @("doctor", "--format", "json")
$capabilitiesRun = Invoke-HuntDogJson -Arguments @("capabilities", "--format", "json")
if ($doctorRun.Error) {
    $warnings.Add("doctor failed: $($doctorRun.Error)")
}
if ($capabilitiesRun.Error) {
    $warnings.Add("capabilities failed: $($capabilitiesRun.Error)")
}
if ($null -eq $doctorRun.Value -or $null -eq $capabilitiesRun.Value) {
    $nextActions.Add("Open WeChat and let the Agent run HuntDog initialization or repair.")
    $result | ConvertTo-Json -Depth 20
    exit 0
}

$doctor = $doctorRun.Value
$capabilities = $capabilitiesRun.Value
$result.initialized = [bool]$doctor.app_context_ready
$configured = [string]$doctor.config_db_dir
$detected = [string]$doctor.auto_detected_db_dir
$mismatch = -not [string]::IsNullOrWhiteSpace($configured) -and
    -not [string]::IsNullOrWhiteSpace($detected) -and
    $configured -ne $detected
$result.requires_account_confirmation = $mismatch
if ($mismatch) {
    $warnings.Add("Configured WeChat account directory differs from the auto-detected active account.")
    $nextActions.Add("Ask the user which WeChat account should be analyzed; do not switch automatically.")
}

$caps = $capabilities.capabilities
$fts = @($capabilities.db_checks | Where-Object { $_.rel_path -eq "message/message_fts.db" } | Select-Object -First 1)
$chatAvailable = [bool]$caps.chat_history
$fullChat = [bool]$caps.chat_history_full_coverage
if ($fullChat) {
    $result.chat_grade = "A"
    $result.ready_for_chat_analysis = -not $mismatch
}
elseif ($chatAvailable -and $fts.Count -gt 0 -and [bool]$fts[0].available) {
    $ftsMtime = $fts[0].mtime
    $result.fts_mtime = $ftsMtime
    $result.fts_mtime_text = $fts[0].mtime_text
    $requestedEndSeconds = $null
    if (-not [string]::IsNullOrWhiteSpace($RequestedEnd)) {
        $parsedEnd = [DateTime]::MinValue
        if (-not [DateTime]::TryParse($RequestedEnd, [ref]$parsedEnd)) {
            throw "RequestedEnd must be YYYY-MM-DD or YYYY-MM-DD HH:MM[:SS]"
        }
        $requestedEndSeconds = [DateTimeOffset]$parsedEnd
        $requestedEndSeconds = $requestedEndSeconds.ToUnixTimeSeconds()
    }
    if ($null -ne $requestedEndSeconds -and ($null -eq $ftsMtime -or [double]$ftsMtime -lt $requestedEndSeconds)) {
        $result.chat_grade = "C"
        $warnings.Add("FTS visible-text index is older than the requested report end time.")
    }
    else {
        $result.chat_grade = "B"
        $result.ready_for_chat_analysis = -not $mismatch
        $warnings.Add("Latest raw chat database is not fully readable; use visible-text wording and directional counts only.")
    }
}

if ([bool]$caps.moments) {
    $result.moments_grade = "A"
    $result.ready_for_moments_analysis = -not $mismatch
    $warnings.Add("Moments grade A means readable locally cached visible Moments, not every post the friend ever published.")
}
if ($result.chat_grade -eq "C") {
    $nextActions.Add("Repair HuntDog chat coverage or request an explicit local export before judging.")
}
if ($result.moments_grade -eq "C") {
    $nextActions.Add("Refresh or repair the local Moments cache before building a profile.")
}

$result.capability_summary = [ordered]@{
    chat_history = [bool]$caps.chat_history
    chat_history_full_coverage = [bool]$caps.chat_history_full_coverage
    moments = [bool]$caps.moments
    contacts = [bool]$caps.contacts
    sessions = [bool]$caps.sessions
    media_assets = [bool]$caps.media_assets
}
if ($Full) {
    $result.doctor = $doctor
    $result.capabilities = $capabilities
}
$result | ConvertTo-Json -Depth 20

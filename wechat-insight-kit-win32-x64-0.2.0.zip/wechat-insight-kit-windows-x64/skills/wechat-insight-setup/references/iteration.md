# Skill 迭代流程

## 1. 保存一个真实失败样例

记录：

- 用户原始请求
- 目标对象、聊天范围和时间范围
- 当次 `probe_huntdog.ps1` 的覆盖等级与警告
- 实际输出
- 用户指出的具体问题
- 用户期待的结果

对样例脱敏。不要保存密钥、数据库路径、完整聊天原文或无关第三方隐私。

## 2. 先分类再修改

只选择一个主故障：

- `触发故障`：该用 Skill 时没有触发，或触发了错误 Skill。
- `安装故障`：框架没有识别、目录错误、版本未刷新。
- `身份故障`：重名、wxid、群名或账号目录没有核对。
- `取数故障`：HuntDog 覆盖不足、时间窗错误、分页不足或降级未生效。
- `分析故障`：事实与推断混淆、忽略反例、回答偏离用户问题。
- `交付故障`：报告缺段、太长、没有证据、移动端不可读。

## 3. 修改最小范围

- 触发问题：只改对应 `SKILL.md` 的 `description`。
- 流程问题：改对应 `SKILL.md` 的步骤或门禁。
- 报告问题：改 `references/report-template.md` 和 linter。
- 底层覆盖问题：优先改 `probe_huntdog.ps1`；不要在三个业务 Skill 里分别写不同规则。
- 跨框架安装问题：改根目录 `scripts/install_skill_pack.ps1` 和 `AGENTS.md`。

## 4. 验证

依次运行：

1. `powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File scripts\validate_pack.ps1`
2. 五个 Skill 的 `quick_validate.py`
3. 三个报告 linter 的正例与反例
4. `install_skill_pack.ps1 -DryRun` 到临时目录
5. 用未泄漏预期答案的新样例做一次前向测试

## 5. 版本与重新加载

- 修复但不改变输入/输出契约：补丁版本加一。
- 新增兼容能力或报告字段：次版本加一。
- 改变安装方式、触发语义或报告契约：主版本加一。

同步更新 `.codex-plugin/plugin.json` 与 `skill-pack.json` 的版本，然后重新构建 ZIP。安装新版后新开任务验证。

## 6. 用户验证

把验证拆开记录：

- Agent 能否成功安装
- 是否找到正确微信账号与对象
- 数据覆盖是否符合预期
- 报告是否回答了问题
- 哪条结论最有用
- 哪条结论不可信或缺证据
- 用户是否愿意下次继续使用

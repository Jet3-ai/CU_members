# 微信洞察技能包：给接收本压缩包的 Agent

当用户上传或解压本包并要求安装、使用或迭代时：

1. 完整读取 `skills/wechat-insight-setup/SKILL.md`。
2. 先判断当前框架是否已把 `.codex-plugin/plugin.json` 和 `skills/` 识别为已安装插件；已识别时不要重复复制。
3. 未识别时，先运行 `python3 scripts/install_skill_pack.py --target <framework> --dry-run`。WorkBuddy 或未知框架必须让 Agent 自己确认技能目录并传 `--dest`，不要猜目录。
4. 在向用户说明目标目录、将安装的五个 Skill 和冲突处理方式后，再执行安装。现有同名 Skill 不得静默覆盖；需要替换时使用 `--replace`，安装器会先备份。
5. 安装完成后运行 `python3 scripts/validate_pack.py`，并建议用户新开任务，让框架重新加载 Skill。
6. 本包已经内置 `skills/wechat-huntdog/assets/bin/macos-arm64/huntdog`。运行 `python3 skills/wechat-insight-setup/scripts/probe_huntdog.py` 检测内置 HuntDog。不得默认寻找或要求用户预装全局 HuntDog。
7. 当前一体包只支持 Apple 芯片 Mac。Windows、Intel Mac 或 Linux 上必须停止并明确说明缺少对应运行核心，不得在线下载未知二进制或伪装成已支持。
8. 不得在账号目录不一致时自行切换账号。先让用户确认本次要分析的是哪个微信账号。
9. 默认只处理本地证据。未经明确同意，不把姓名、微信号、聊天原文或朋友圈内容发送到网页搜索、外部接口或第三方服务。
10. 首次使用时给用户展示三个可直接复制的示例请求，并说明报告都会标注 A/B/C 证据覆盖等级。
11. 用户提出“迭代 Skill”时，按 `skills/wechat-insight-setup/references/iteration.md` 收集失败样例、修改最小范围、验证、升级版本并重新安装；不要只改提示词后宣称已验证。

本包提供的是分析工作流，不承诺完整微信备份、法证级完整性、医学/心理诊断或对他人内心的确定判断。

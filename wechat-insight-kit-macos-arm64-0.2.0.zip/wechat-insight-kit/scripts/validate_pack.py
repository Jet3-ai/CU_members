#!/usr/bin/env python3
"""Validate the portable WeChat insight skill pack."""

from __future__ import annotations

import json
import hashlib
import re
import sys
from pathlib import Path


PACK_ROOT = Path(__file__).resolve().parents[1]


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def main() -> None:
    plugin_path = PACK_ROOT / ".codex-plugin" / "plugin.json"
    pack_path = PACK_ROOT / "skill-pack.json"
    try:
        plugin = json.loads(plugin_path.read_text(encoding="utf-8"))
        pack = json.loads(pack_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        fail(str(exc))

    if plugin.get("name") != pack.get("name"):
        fail("plugin and skill-pack names differ")
    if plugin.get("version") != pack.get("version"):
        fail("plugin and skill-pack versions differ")

    expected = pack.get("skills") or []
    if len(expected) != len(set(expected)) or not expected:
        fail("skill list is empty or contains duplicates")

    for name in expected:
        root = PACK_ROOT / "skills" / name
        skill_md = root / "SKILL.md"
        agent_yaml = root / "agents" / "openai.yaml"
        if not skill_md.is_file():
            fail(f"missing {skill_md}")
        if not agent_yaml.is_file():
            fail(f"missing {agent_yaml}")
        text = skill_md.read_text(encoding="utf-8")
        match = re.search(r"(?m)^name:\s*([a-z0-9-]+)\s*$", text)
        if not match or match.group(1) != name:
            fail(f"frontmatter name mismatch for {name}")
        if "[TODO:" in text or "[TODO" in text:
            fail(f"unfinished TODO in {skill_md}")

    if (pack.get("distribution") or {}).get("bundled_backend"):
        binary = PACK_ROOT / "skills" / "wechat-huntdog" / "assets" / "bin" / "macos-arm64" / "huntdog"
        wrapper = PACK_ROOT / "skills" / "wechat-huntdog" / "scripts" / "huntdog"
        if not binary.is_file() or binary.stat().st_size < 1_000_000:
            fail("bundled HuntDog binary is missing or unexpectedly small")
        if not wrapper.is_file():
            fail("bundled HuntDog wrapper is missing")
        expected_sha = (pack.get("backend") or {}).get("binary_sha256")
        actual_sha = hashlib.sha256(binary.read_bytes()).hexdigest()
        if expected_sha != actual_sha:
            fail("bundled HuntDog binary checksum does not match skill-pack.json")

    print(f"OK: {pack['name']} {pack['version']} ({len(expected)} skills)")


if __name__ == "__main__":
    main()

---
name: wechat-moments-profile
description: Analyze a specified WeChat friend's locally cached visible Moments and produce an evidence-backed profile with identity anchoring, timelines, topic evolution, expression patterns, counterevidence, uncertainty, and A/B/C coverage labeling. Use when the user asks to 分析好友朋友圈, 扒朋友圈, 做人物画像, 看一个人的长期变化, summarize what a friend cares about, or assess collaboration fit from Moments. Requires the WeChat Insight Kit and CyberUnion HuntDog.
---

# 好友朋友圈画像

根据本机缓存的可见朋友圈生成“内容与行为证据画像”，不把内容选择推断成医学诊断、人格真相或完整人生。

始终通过同包内 `$wechat-huntdog` 的绝对启动器运行数据命令：

`<skills目录>/wechat-huntdog/scripts/huntdog`

不要假设存在全局 `huntdog` 或 `wechat-cli`。

## 输入

开始前获得：

- 好友姓名、备注或 `wxid`
- 用户最想了解的问题
- 时间范围；未指定时使用该好友在本机缓存中的全部可见范围
- 可选输出目录

信息已足够时直接执行。重名或账号目录冲突会改变证据对象，必须先确认。

## 1. 运行能力门禁

从本 Skill 路径调用：

`python3 ../wechat-insight-setup/scripts/probe_huntdog.py [--requested-end "<结束时间>"]`

仅在 `ready_for_moments_analysis=true` 时继续。报告首屏写：

- `证据覆盖等级：A`
- `证据范围：本地缓存可见朋友圈`
- 实际起止时间、命中条数、解析失败数

这里的 A 只表示当前本地朋友圈缓存可读，不表示覆盖删除、未缓存、不可见或从未下载的动态。

## 2. 锁定好友身份

依次运行：

1. `<内置 HuntDog 启动器> contacts --query "<姓名或备注>" --format json`
2. 用户输入已是 `wxid` 或候选唯一时，运行 `<内置 HuntDog 启动器> contacts --detail "<wxid>" --format json`

保留昵称、备注、别名和 `wxid` 的对应关系。出现多个候选时展示最小识别信息，让用户选择；不得合并同名联系人。

## 3. 分页读取朋友圈

优先使用 JSON，保留正文、时间、作者标识、内容类型、媒体数量和链接：

`<内置 HuntDog 启动器> moments --author "<已确认的 wxid>" --start-time "<开始>" --end-time "<结束>" --limit 500 --offset 0 --format json`

根据 `total` 与 `count` 继续增加 `offset`，直到覆盖目标范围。不要只分析前 20 条。

在用户确认的本地输出目录建立权限受限的任务目录。原始 JSON 与报告分开保存；默认不生成 PDF，不把原始数据发往外部搜索。

## 4. 建立证据模型

按时间和重复度整理：

- 阶段变化与转折
- 反复出现的主题、活动与关注对象
- 内容形式：原创文字、转发链接、图片/视频占比线索
- 可观察的表达与沟通习惯
- 工作、项目、学习、生活线索
- 公开自我定位与其变化
- 反例、不一致和沉默区

只把重复出现、跨时间成立的模式写进核心画像。单条动态只能作为线索。

若图片正文、评论或点赞数据不可读，明确写“未纳入”，不得凭媒体数量猜图像内容或社交关系。

## 5. 回答用户真正的问题

先给结论，再解释证据。每个核心判断至少包含：

- 判断
- 2 条以上带日期证据，或说明只有弱证据
- 可能的另一种解释
- 置信度

区分：

- `事实`：朋友圈中直接可见
- `推断`：从重复模式得出
- `未知`：当前缓存无法回答

## 6. 写入并校验报告

使用 [references/report-template.md](references/report-template.md)。必要原文只保留短摘录，优先转述，不附整段朋友圈。

运行：

`python3 scripts/lint_moments_report.py <报告.md>`

修订直到返回 `OK`。

## 边界

- 不诊断 ADHD、抑郁、人格、依恋或其他医学/心理状态。
- 不把发朋友圈的频率等同于现实生活状态。
- 不声称看到了对方“全部朋友圈”。
- 不自动做人脸识别、OCR 或外部账号关联。
- 用户明确要求公开信息交叉验证时，先征得将哪些最小身份字段用于外部搜索的同意。
- 输出只服务于用户自己的理解与决策，不生成骚扰、操控、歧视或公开曝光材料。

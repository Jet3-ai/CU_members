---
name: wechat-huntdog
description: Use when an agent needs to query or reason over the user's local WeChat data with CyberUnion HuntDog / 微信猎犬, including environment checks, chat history, message search, contacts, group members, official-account pushes, Moments, favorites, unread sessions, incremental messages, exports, or debugging. Trigger on 微信猎犬, HuntDog, 本地微信, 微信聊天记录, 群成员, 公众号, 朋友圈, 收藏, 未读, 微信导出.
---

# 微信猎犬

Run the bundled HuntDog core through this skill's `scripts/huntdog` wrapper. Resolve this skill directory from the loaded `SKILL.md` path, then invoke the wrapper by absolute path. Do not require a global HuntDog installation. On first use, the wrapper stages the bundled core under `~/.huntdog/runtime/` so it can start reliably even when the imported Skill lives in a long or non-ASCII path.

Do not ask the user to open Terminal or copy commands. Run HuntDog commands with the agent's shell tool. Only ask the user to open and log in to WeChat, grant macOS permissions, or confirm data scope when necessary.

## Start every data task

Run these read-only checks unless the user only asks for syntax:

```bash
"<skill-directory>/scripts/huntdog" doctor --format text
"<skill-directory>/scripts/huntdog" capabilities --format text
```

If HuntDog is not initialized, ask the user to keep WeChat open, then run:

```bash
"<skill-directory>/scripts/huntdog" init
```

If macOS blocks access or key extraction, explain the exact permission needed. Do not use `sudo`, change system settings, or bypass security controls without explicit user approval.

## Privacy rules

- Treat all WeChat data as private local user data.
- Keep searches scoped by chat, keyword, date range, account, or message type.
- Ask before broad cross-WeChat searches, large exports, or writing output files.
- Summarize results instead of pasting long raw histories.
- Separate facts, direct evidence, inference, and uncertainty when analyzing people or relationships.
- Never send, publish, delete, or modify WeChat data. This skill is for local reading and export only.
- Do not expose raw `wxid_` identifiers, keys, database paths, or personal data unless the task strictly requires them.

## Command routing

Use the absolute wrapper path in place of `huntdog` below:

- Environment: `huntdog doctor --format text`
- Capability map: `huntdog capabilities --format text`
- Recent conversations: `huntdog sessions --limit 20 --format text`
- Chat history: `huntdog history "名称" --limit 50 --format text`
- Message search: `huntdog search "关键词" --chat "聊天名" --format text`
- Contacts: `huntdog contacts --query "名称" --format text`
- Group members: `huntdog members "群名" --format text`
- Chat stats: `huntdog stats "群名" --format text`
- Chat export: `huntdog export "群名" --format markdown --output chat.md`
- Article links: `huntdog article-links "群名" --format text`
- Official accounts: `huntdog biz-accounts --query "关键词" --format text`
- Official-account search: `huntdog biz-search "关键词" --account "公众号名" --format text`
- Official-account export: `huntdog biz-export "公众号名" --keyword "关键词" --output articles.md`
- Moments: `huntdog moments "关键词" --author "名称" --format text`
- Moments export: `huntdog moments-export "关键词" --output moments.md`
- Favorites: `huntdog favorites --type article --query "关键词" --format text`
- Favorites export: `huntdog favorites-export --type article --output favorites.md`
- Unread sessions: `huntdog unread --format text`
- Incremental messages: `huntdog new-messages --format text`

## Detailed reference

Read `references/HUNTDOG_USAGE.md` when the request needs date filters, message types, exports, official accounts, Moments, favorites, or troubleshooting.

## Platform boundary

The bundled runtime supports Apple-silicon macOS (`arm64`). If `scripts/huntdog` reports an unsupported platform, stop and tell the user this package needs a runtime built for their operating system and CPU. Do not download or execute a replacement binary automatically.

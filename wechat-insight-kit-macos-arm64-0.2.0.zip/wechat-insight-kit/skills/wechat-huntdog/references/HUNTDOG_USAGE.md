# CyberUnion HuntDog 使用说明

HuntDog 是本地微信数据工具。默认只读取用户本机数据，适合让 AI agent 在用户授权下检索聊天、联系人、群成员、公众号推送、朋友圈、收藏、未读和增量消息。

购买用户不需要打开终端，也不需要复制命令。所有 HuntDog 调用都应由 Codex、Claude Code、WorkBuddy 等 AI 工具在后台执行。

Agent 执行时优先使用绝对路径：

```bash
$HOME/.huntdog/bin/huntdog
```

如果当前 shell 已经能找到别名，也可以使用短命令 `huntdog`。

## 默认工作流

新机器或不确定状态时，先运行：

```bash
$HOME/.huntdog/bin/huntdog doctor --format text
$HOME/.huntdog/bin/huntdog capabilities --format text
```

如果还没有初始化，让用户只负责打开微信；初始化命令由 AI 工具执行：

```bash
$HOME/.huntdog/bin/huntdog init
```

macOS 如果密钥提取失败，由 AI 工具在获得用户同意后尝试：

```bash
sudo $HOME/.huntdog/bin/huntdog init --force
```

## 隐私与边界

- 默认做本地只读检索，不主动导出大段聊天。
- 不要要求用户手动输入 HuntDog 命令。
- 大范围搜索、跨群检索、导出文件前，先让用户确认聊天对象、关键词、时间范围和输出位置。
- 回答时优先总结结论，引用少量必要原文，不把完整聊天记录粘贴到外部服务。
- 如果用户要求分析敏感关系、合作、财务或隐私话题，先缩小范围再读取。

## Agent 后台命令参考

### 自检与能力

```bash
huntdog doctor --format text
huntdog capabilities --format text
```

`doctor` 用来检查配置、密钥、数据库目录和消息库覆盖情况。`capabilities` 用来判断当前机器可用哪些能力。

### 会话与未读

```bash
huntdog sessions --limit 20 --format text
huntdog unread --limit 20 --format text
huntdog new-messages --format text
```

`new-messages` 会记录上次检查时间，适合做增量提醒。

### 聊天历史与搜索

```bash
huntdog history "聊天名" --limit 50 --format text
huntdog history "聊天名" --start-time "2026-06-01" --end-time "2026-06-15" --format text
huntdog search "关键词" --chat "聊天名" --limit 50 --format text
huntdog search "关键词" --chat "群A" --chat "群B" --type link --format text
```

常用消息类型过滤包括 `text`、`image`、`voice`、`video`、`link`、`file`。

### 联系人与群成员

```bash
huntdog contacts --query "昵称或备注" --format text
huntdog contacts --detail "昵称或wxid" --format text
huntdog members "群名" --format text
```

先用 `contacts --query` 或 `sessions` 解决重名问题，再读历史会更稳。

### 统计与导出

```bash
huntdog stats "聊天名" --start-time "2026-06-01" --end-time "2026-06-15" --format text
huntdog export "聊天名" --format markdown --start-time "2026-06-01" --limit 1000 --output chat.md
huntdog article-links "聊天名" --start-time "2026-06-01" --format text
```

导出前确认文件名和范围。

### 公众号

```bash
huntdog biz-accounts --query "AI" --format text
huntdog biz-search "关键词" --account "公众号名" --format text
huntdog biz-export "公众号名" --keyword "关键词" --format markdown --output articles.md
```

公众号通常只有本机缓存过的推送卡片元数据，不保证有文章正文。

### 朋友圈

```bash
huntdog moments "关键词" --author "昵称" --limit 20 --format text
huntdog moments-export "关键词" --author "昵称" --format markdown --output moments.md
```

朋友圈能力取决于本机缓存，适合做动态检索和链接整理。

### 收藏

```bash
huntdog favorites --type article --query "关键词" --format text
huntdog favorites-export --type article --query "关键词" --format markdown --output favorites.md
```

收藏适合做个人知识库、文章线索和主题归档。

## Agent 输出建议

- 先说明读取范围和命令。
- 汇总结论，再列证据。
- 如果命令失败，先贴关键错误和下一步，不猜测用户隐私内容。
- 对多人、群聊、合作关系类问题，区分事实、推断和不确定性。

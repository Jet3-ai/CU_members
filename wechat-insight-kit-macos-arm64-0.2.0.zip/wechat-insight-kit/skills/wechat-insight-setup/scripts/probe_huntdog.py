#!/usr/bin/env python3
"""Probe HuntDog without exposing raw WeChat data and assign evidence grades."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any


def backend_candidates() -> list[str]:
    bundled = Path(__file__).resolve().parents[2] / "wechat-huntdog" / "scripts" / "huntdog"
    candidates = [
        str(bundled),
        os.environ.get("HUNTDOG_BIN"),
        str(Path.home() / ".huntdog" / "bin" / "huntdog"),
        shutil.which("huntdog"),
        shutil.which("cyberunion-huntdog"),
        shutil.which("wechat-cli"),
    ]
    found: list[str] = []
    for candidate in candidates:
        if candidate and Path(candidate).expanduser().is_file():
            normalized = str(Path(candidate).expanduser())
            if normalized not in found:
                found.append(normalized)
    return found


def find_backend() -> tuple[str | None, str | None, list[str]]:
    failures: list[str] = []
    for candidate in backend_candidates():
        try:
            version = subprocess.run(
                [candidate, "--version"],
                check=False,
                capture_output=True,
                text=True,
                timeout=10,
            )
        except subprocess.TimeoutExpired:
            failures.append(f"{candidate}: version check timed out")
            continue
        if version.returncode != 0:
            failures.append(f"{candidate}: version check exited {version.returncode}")
            continue
        label = (version.stdout or version.stderr).strip()
        return candidate, label, failures
    return None, None, failures


def run_json(command: str, *args: str) -> tuple[dict[str, Any] | None, str | None]:
    try:
        completed = subprocess.run(
            [command, *args],
            check=False,
            capture_output=True,
            text=True,
            timeout=60,
        )
    except subprocess.TimeoutExpired:
        return None, f"{' '.join(args)} timed out"
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout or "unknown error").strip()
        return None, detail[-1000:]
    try:
        return json.loads(completed.stdout), None
    except json.JSONDecodeError:
        return None, "backend did not return valid JSON"


def parse_requested_end(value: str | None) -> float | None:
    if not value:
        return None
    formats = ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d")
    for pattern in formats:
        try:
            return datetime.strptime(value, pattern).timestamp()
        except ValueError:
            continue
    raise ValueError("requested end must be YYYY-MM-DD or YYYY-MM-DD HH:MM[:SS]")


def db_check(capabilities: dict[str, Any], rel_path: str) -> dict[str, Any] | None:
    for item in capabilities.get("db_checks") or []:
        if item.get("rel_path") == rel_path:
            return item
    return None


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--requested-end", help="Requested report end time for FTS freshness grading")
    parser.add_argument("--full", action="store_true", help="Include raw doctor/capabilities JSON")
    args = parser.parse_args()

    requested_end = parse_requested_end(args.requested_end)
    command, version_label, candidate_failures = find_backend()
    result: dict[str, Any] = {
        "backend_found": bool(command),
        "backend_command": command,
        "initialized": False,
        "requires_account_confirmation": False,
        "chat_grade": "C",
        "moments_grade": "C",
        "ready_for_chat_analysis": False,
        "ready_for_moments_analysis": False,
        "unsupported_platform": False,
        "warnings": candidate_failures,
        "next_actions": [],
    }
    if not command:
        import platform

        supported = platform.system() == "Darwin" and platform.machine() == "arm64"
        result["unsupported_platform"] = not supported
        if supported:
            result["next_actions"].append("Repair or reinstall the bundled wechat-huntdog skill, then run this probe again.")
        else:
            result["next_actions"].append("This package currently needs an Apple-silicon Mac runtime build.")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    result["backend_version"] = version_label

    doctor, doctor_error = run_json(command, "doctor", "--format", "json")
    capabilities, capabilities_error = run_json(command, "capabilities", "--format", "json")
    if doctor_error:
        result["warnings"].append(f"doctor failed: {doctor_error}")
    if capabilities_error:
        result["warnings"].append(f"capabilities failed: {capabilities_error}")
    if not doctor or not capabilities:
        result["next_actions"].append("Open WeChat and let the Agent run HuntDog initialization or repair.")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    result["initialized"] = bool(doctor.get("app_context_ready"))
    configured = doctor.get("config_db_dir")
    detected = doctor.get("auto_detected_db_dir")
    mismatch = bool(configured and detected and configured != detected)
    result["requires_account_confirmation"] = mismatch
    if mismatch:
        result["warnings"].append("Configured WeChat account directory differs from the auto-detected active account.")
        result["next_actions"].append("Ask the user which WeChat account should be analyzed; do not switch automatically.")

    caps = capabilities.get("capabilities") or {}
    fts = db_check(capabilities, "message/message_fts.db")
    chat_available = bool(caps.get("chat_history"))
    full_chat = bool(caps.get("chat_history_full_coverage"))
    if full_chat:
        result["chat_grade"] = "A"
        result["ready_for_chat_analysis"] = not mismatch
    elif chat_available and fts and fts.get("available"):
        fts_mtime = fts.get("mtime")
        result["fts_mtime"] = fts_mtime
        result["fts_mtime_text"] = fts.get("mtime_text")
        if requested_end is not None and (not fts_mtime or float(fts_mtime) < requested_end):
            result["chat_grade"] = "C"
            result["warnings"].append("FTS visible-text index is older than the requested report end time.")
        else:
            result["chat_grade"] = "B"
            result["ready_for_chat_analysis"] = not mismatch
            result["warnings"].append(
                "Latest raw chat database is not fully readable; use visible-text wording and directional counts only."
            )

    if caps.get("moments"):
        result["moments_grade"] = "A"
        result["ready_for_moments_analysis"] = not mismatch
        result["warnings"].append(
            "Moments grade A means readable locally cached visible Moments, not every post the friend ever published."
        )

    if result["chat_grade"] == "C":
        result["next_actions"].append("Repair HuntDog chat coverage or request an explicit local export before judging.")
    if result["moments_grade"] == "C":
        result["next_actions"].append("Refresh or repair the local Moments cache before building a profile.")

    result["capability_summary"] = {
        key: bool(caps.get(key))
        for key in (
            "chat_history",
            "chat_history_full_coverage",
            "moments",
            "contacts",
            "sessions",
            "media_assets",
        )
    }
    if args.full:
        result["doctor"] = doctor
        result["capabilities"] = capabilities
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

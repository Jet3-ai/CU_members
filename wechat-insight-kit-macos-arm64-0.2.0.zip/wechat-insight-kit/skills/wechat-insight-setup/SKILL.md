---
name: wechat-insight-setup
description: Install, verify, onboard, route, and iterate the self-contained Apple-silicon Mac WeChat Insight Kit with its bundled CyberUnion HuntDog runtime. Use when the user uploads the pack, asks to install 微信洞察技能包, configure it for Codex, Claude, WorkBuddy, or another Agent framework, check local WeChat data readiness, choose among the three included analysis skills, learn first-use prompts, or update the skills after a failed or incomplete result.
---

# 微信洞察安装、自检与迭代

把安装、HuntDog 能力门禁、首次使用和后续迭代收束成一次引导。不要让非技术用户手动复制终端命令；由当前 Agent 执行可执行的步骤，只让用户确认权限、账号、安装目标和分析范围。

## 安装

1. 定位本包根目录；它必须包含 `.codex-plugin/plugin.json`、`skill-pack.json`、`skills/` 和 `scripts/`。
2. 判断当前框架是否已经识别插件内的四个 Skill。已识别时跳过复制。
3. 未识别时先执行：

   `python3 <包根目录>/scripts/install_skill_pack.py --target <codex|claude|workbuddy|generic> --dry-run [--dest <技能目录>]`

4. 向用户说明目标目录、将安装的五个 Skill、是否有同名冲突。五个 Skill 包含内置 HuntDog 运行核心；只有用户确认后才真正写入框架目录。
5. 同名 Skill 不得静默覆盖。用户确认替换后使用 `--replace`；安装器会把旧版移动到 `.wechat-insight-backups/<时间>/`。
6. 执行 `python3 <包根目录>/scripts/validate_pack.py`。
7. 提醒用户新开一个任务，使框架重新加载 Skill。

WorkBuddy 和未知框架没有可信的通用技能路径。必须由 Agent 检查该框架当前导入目录，或让用户在界面中选择导入位置，再传 `--dest`；不要猜路径。

## 内置 HuntDog 与能力门禁

默认用户没有安装 HuntDog。本包通过 `$wechat-huntdog` 自带 Apple 芯片 Mac 版 HuntDog 0.4.0；不要先检查或要求全局安装。

从本 Skill 目录运行：

`python3 scripts/probe_huntdog.py [--requested-end "YYYY-MM-DD HH:MM:SS"]`

按结果处理：

- `backend_found=false`：检查 `../wechat-huntdog/` 是否完整、当前平台是否为 macOS arm64，以及框架是否漏装该 Skill。不要把缺失转嫁为“请用户预装 HuntDog”。
- `unsupported_platform=true`：明确说明当前一体包只支持 Apple 芯片 Mac。Windows、Intel Mac 和 Linux 尚无本包可用运行核心。
- `initialized=false`：让用户打开微信，由 Agent 运行 `huntdog init`。只有普通初始化失败且用户了解原因后，才请求运行需要管理员权限的初始化。
- `requires_account_confirmation=true`：暂停分析，展示配置账号与自动检测账号不一致这一事实，让用户确认目标账号。不得自行 `init --force` 或切换。
- `chat_grade=A`：允许完整度范围内的精确统计，但仍不能声称法证级完整。
- `chat_grade=B`：只把数量写成“可见文本消息数”，只做方向性判断，并使用“可见文本中未观察到”。
- `chat_grade=C`：停止聊天结论，修复底层或请用户提供明确导出材料。
- `moments_grade=A`：仅代表本机可读取缓存朋友圈；报告仍必须写“本地缓存可见朋友圈”，不能扩张为对方全部朋友圈。

不要把 `doctor` 输出里的数据库路径、密钥状态文件或原始聊天内容发到网页或第三方接口。

## 路由到三个业务 Skill

- 指定好友的朋友圈画像：使用 `$wechat-moments-profile`。
- 指定好友在群聊/私聊里的发言分析：使用 `$wechat-person-chat-analysis`。
- 多个群在指定时段内的群聊报告：使用 `$wechat-group-report`。

首次安装后，给用户展示 [references/first-use.md](references/first-use.md) 中的三个直接可用请求。

## 迭代

用户说“这个 Skill 不好用”“漏了某类信息”“我要改报告结构”或“基于这次结果迭代”时，完整读取 [references/iteration.md](references/iteration.md)，用真实失败样例驱动最小修改、校验、版本升级和重新安装。

不得把一次成功生成文件当作产品有效；至少区分：

- 安装成功
- 数据能力可用
- 报告结构通过校验
- 用户认为结论有用
- 用户愿意再次使用或付费

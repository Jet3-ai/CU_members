---
name: wechat-person-chat-analysis
description: Analyze a specified friend's own messages and surrounding context in user-selected WeChat private chats and group chats, then answer a concrete user question with identity verification, scoped evidence, counterevidence, uncertainty, and A/B/C coverage labels. Use for requests like 分析某个好友的聊天记录, 看他在这些群里说了什么, 总结某人的观点, 判断谁推动了事情, compare what a person said in group and private chat, or derive a bounded conclusion about a named contact from selected chats. Requires the WeChat Insight Kit and CyberUnion HuntDog.
---

# 指定好友聊天分析

围绕用户提出的一个具体问题，分析指定好友在明确聊天范围中的发言与必要上下文。不要把“搜到这个名字”当成“确认是这个人”。

始终通过同包内 `$wechat-huntdog` 的绝对启动器运行数据命令：

`<skills目录>/wechat-huntdog/scripts/huntdog`

不要假设存在全局 `huntdog` 或 `wechat-cli`。

## 输入

获得：

- 指定好友的姓名、备注或 `wxid`
- 指定聊天：一个或多个群聊、与用户的私聊，或两者
- 开始与结束时间；未指定时先让用户确认是否接受全部可见历史
- 用户想得到的具体结论
- 可选输出目录

把缺失项合并成一次简短确认。具体问题决定证据筛选和报告结构，不要生成泛泛人物画像替代答案。

## 1. 能力与账号门禁

运行：

`python3 ../wechat-insight-setup/scripts/probe_huntdog.py [--requested-end "<结束时间>"]`

- `A`：允许使用成功返回的原始库统计；当前 CLI 的同分钟排序和渲染截断仍不适合精确响应时延判断。
- `B`：只做可见文本的方向性分析；数量写“可见文本消息数”，否定判断写“可见文本中未观察到”。
- `C`：停止结论，修复 HuntDog 或使用用户明确提供的本地导出材料。

账号目录不一致时暂停并请用户确认，不得自动切换。

## 2. 锁定好友与聊天身份

1. 用 `<内置 HuntDog 启动器> contacts --query "<好友>" --format json` 获取候选。
2. 用 `<内置 HuntDog 启动器> contacts --detail "<wxid>" --format json` 固定好友身份。
3. 对每个群聊用联系人查询或会话列表固定 `...@chatroom`。
4. 用 `<内置 HuntDog 启动器> members "<群 wxid 或群名>" --format json` 核对好友在群内的身份。
5. 私聊也优先使用已确认 `wxid` 读取。

出现重名、旧联系人、同名群或好友不在群成员列表时，先向用户展示冲突，不得合并证据。

## 3. 读取完整目标时段

对每个已确认聊天运行：

`<内置 HuntDog 启动器> history "<聊天 wxid>" --start-time "<开始>" --end-time "<结束>" --limit 5000 --offset 0 --format json`

若返回达到 `limit`，继续增加 `offset`，直到时段覆盖完成。保存每个聊天的：

- 展示名与稳定 `username`
- 是否群聊
- 实际返回范围
- `failures`
- 覆盖等级

当用户的问题涉及某个主题，再补：

`<内置 HuntDog 启动器> search "<关键词>" --chat "<聊天 wxid>" --start-time "<开始>" --end-time "<结束>" --limit 500 --format json`

搜索只能补充定位，不能替代读取指定聊天的上下文。

## 4. 分离目标发言与上下文

建立三层证据：

- `目标好友原话`：明确归属于已确认对象的消息
- `上下文`：用户或其他成员在前后的必要发言
- `他人评价/提及`：只能证明别人说了什么，不能当作目标好友自己的观点

群聊与私聊分别分析，再比较一致点、差异和场景影响。引用只用必要短摘录，并保留日期和聊天来源。

## 5. 形成结论

围绕用户问题组织：

- 直接结论
- 支持证据
- 反对证据或另一种解释
- 群聊/私聊差异
- 置信度
- 当前不能判断的部分

因果、动机、关系、财务、安全、法律或心理结论需要更高证据。聊天覆盖为 B 时，不得用缺失内容证明某件事没有发生。

## 6. 报告与校验

使用 [references/report-template.md](references/report-template.md)。

运行：

`python3 scripts/lint_person_chat_report.py <报告.md>`

修订直到返回 `OK`。移动端用户优先把关键结论和覆盖边界直接写在对话中，Markdown 作为证据档案。

## 边界

- 不自动扩大到用户没有指定的聊天、联系人或时间。
- 不把群成员的观点归给目标好友。
- 不根据聊天文本诊断医学、心理或人格状态。
- 不推断对方的隐秘意图、收入、资产、感情事实或违法行为。
- 不把完整聊天原文发送到网页搜索或第三方服务。
- 用户明确要求外部核验时，先确认可使用的最小身份字段和搜索目的。
